"""Refresh all scope-dependent metadata; keep raw and site evidence separate."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import data_io as raw
from common import load,dump,FMT

def finish(root,analysis,output,cfg):
    p=load(analysis/'产品级标签.csv',['start','end','label_available_at']);a=load(analysis/'停喷观察全量.csv',['start','end']);m=load(analysis/'来源文件清单.csv',['time_start','time_end']).fillna({'zip_member':'','identical_bytes_to':''})
    records=json.loads((analysis/'Booth2换枪记录与窗口核对.json').read_text('utf-8'))
    g10=next(g for g in records if g['record_id']=='G010')
    g10['window_match_precision']='after_work_range_not_unique_window'
    g10['window_mapping_confirmed']=False
    g10['site_note']='现场确认11/6生产结束后提前更换；实际操作仅限定在结束生产后至当天结束。W174只是首段长停喷示例，不能确认只在该段内操作。'
    for g in records:
        left=g.get('previous_new_serial','');right=g.get('old_serial','')
        g['serial_chain_state']='not_comparable' if not left or not right else 'matched' if left==right else 'mismatched'
    dump(records,analysis/'Booth2换枪记录与窗口核对.json');raw.write_csv(pd.DataFrame(records),analysis/'Booth2换枪记录与窗口核对.csv');raw.write_csv(pd.DataFrame(records),output/'model_data/maintenance_events.csv')
    for g in records:
        if g['action_type'] in ['preventive','replacement_after_reported_damage']:continue
        for wid in filter(None,g['supported_window_ids'].split(';')):
            w=a[a.window_id.eq(wid)].iloc[0];hit=p.product_id.isin(str(w.low_product_ids).split(';'))&p.voltage_fail.eq(1)&p.cause_basis.eq('low_voltage_cause_unresolved')
            p.loc[hit,['origin_label','origin_evidence','cause_basis']]=['连续低压后更换（登记与信号对应）','产品低压序列后停喷，与该日更换登记或现场确认对应；实际拆装分钟未知。','register_and_low_sequence_eol_inference']
    hit=p.label_valid.eq(0);p.loc[hit,'origin_label']=np.where(p.loc[hit,'quality_flags'].fillna('').str.contains('其他配方'),'其他配方测试工单（排除）','加工边界或有效点不完整（排除）')
    p.loc[hit,'origin_evidence']='不进入本工艺训练、验证、测试样本；保留实测均值和来源，failure留空。'
    r=a[a.window_id.eq('W105')].iloc[0];h=p.product_id.isin(str(r.low_product_ids).split(';'))
    p.loc[h,'origin_label']='短寿命电极的早段低压，未确认当时换新'
    p.loc[h,'origin_evidence']='10/15早段低压后重启线索保留；现场确认实际更换在中午W108，不能把早段再计作一次换枪。'
    p.loc[h,'cause_basis']='site_no_additional_change_inferred_instability'
    # Include the next working day's first products after an end-of-day preventive change.
    next_work=p[p.start.gt(pd.to_datetime(g10['action_time_upper'],format=FMT))].head(3)
    for ix in next_work.index:
        p.loc[ix,'attention']=1
        for col in ['record_context_ids','rule_supported_record_ids']:
            before=p.loc[ix,col] if pd.notna(p.loc[ix,col]) else ''
            p.loc[ix,col]=';'.join(dict.fromkeys(filter(None,[*before.split(';'),'G010'])))
    raw.write_csv(p,analysis/'产品级标签.csv')
    # Both source rows of the single newly observed timestamp conflict are auditable.
    f=root/'20261102-20261107/20261102-20261107/06_Nov_2026H18.csv'
    d=raw.parse_csv(f.read_bytes());d['source_row']=np.arange(len(d))+2
    q=d[d.timestamp.duplicated(keep=False)];raw.write_csv(q,analysis/'重复时间戳原始两行.csv',raw=True)
    assert len(q)==2 and q.timestamp.iloc[0]==pd.Timestamp('2026-11-06 18:19:51')
    main=m[m.data_stream.eq('main')&m.identical_bytes_to.eq('')&m.rows.gt(0)].copy();main['day']=main.time_start.dt.strftime('%Y-%m-%d')
    raw.write_csv(main.groupby('day').agg(files=('source_id','size'),raw_rows=('rows','sum'),first=('time_start','min'),last=('time_end','max')).reset_index(),analysis/'每日数据检查.csv')
    sensitivity=load(analysis/'分段参数敏感性.csv');sensitivity['scope']=cfg['analysis_start']+' — '+cfg['analysis_end_exclusive']
    sensitivity['scope_note']='保留同一转台换向低速点；选用2秒，1/2/3秒结果在本表对照；非官方质量阈值'
    raw.write_csv(sensitivity,analysis/'分段参数敏感性.csv')
    segment=json.loads((analysis/'产品分段核对.json').read_text('utf-8'));segment['duration_review']=int(p.label_valid.eq(0).sum());segment['review_meaning']='已排除的其他配方或不完整区间，不是新增待现场问题';dump(segment,analysis/'产品分段核对.json')
    ref=load(analysis/'参考样本/末期产品核对.csv',['start','end'])
    # Shared segmentation used neutral placeholders; never deliver them as measured Booth1 sensors.
    ref=ref[[col for col in ref if col in ['product_id','start','end','station','duration_seconds','samples','coverage','voltage_mean','voltage_min','voltage_p10','voltage_std','label_valid','quality_flags','reference_voltage_fail','derived_voltage_rule_trigger','source_start','source_end','source_row_start','source_row_end','turnaround_points','turnaround_times']]]
    raw.write_csv(ref,analysis/'参考样本/末期产品核对.csv')
    ri=json.loads((analysis/'参考样本/参考信息.json').read_text('utf-8'));ri.update(allowed_columns=['Date-Time','Voltage','Station_1','Station_2'],reference_product_intervals=len(ref),reference_low_voltage_intervals=int(ref.reference_voltage_fail.eq(1).sum()),reference_product_note='完整加工周期，包含短暂换向低速点；仅电压作比较，转台仅用于划分区间。参考过程不作独立寿命多次计数。');dump(ri,analysis/'参考样本/参考信息.json')
    z=np.load(analysis/'传感器计时与转台状态.npz');ts=z['timestamp_seconds'];pos=np.flatnonzero(np.diff(ts)>2)
    raw.write_csv(pd.DataFrame(dict(after=pd.to_datetime(ts[pos],unit='s'),before=pd.to_datetime(ts[pos+1],unit='s'),unobserved_seconds=np.diff(ts)[pos]-1)),analysis/'日内采样缺口.csv')
    # Replace obsolete prior-scope minute plots, never export old-scope cached statistics as current.
    minutes=pd.read_csv(output/'model_data/sensor_minutes.csv.gz');raw.write_csv(minutes[['timestamp','Voltage','observed_points','quality_valid']],analysis/'主数据电压分钟走势.csv')
    s=json.loads((analysis/'汇总.json').read_text('utf-8'));new=main[main.time_start.ge('2026-11-02')]
    s['attention_products']=int(p.attention.sum())
    s['unique_rule_matches']=sum(g['match_state']=='unique_site_rule' for g in records)
    s['site_confirmed_matches']=sum(g['match_state']=='site_confirmed' and g['record_id']!='G010' for g in records)
    s['after_work_range_matches']=1
    s['rule_supported_stop_windows']=int((a.site_rule_window_supported&a.site_rule_stop_eligible).sum())
    s['serial_chain_issues']=sum(g['serial_chain_state']=='mismatched' for g in records)
    s['excel_vs_site_serial_observation_conflicts']=1
    s['new_data']=dict(added_files=len(new),added_rows=int(new.rows.sum()),start=new.time_start.min(),end=new.time_end.max(),new_products=int(p.start.ge('2026-11-02').sum()),new_failures=int((p.start.ge('2026-11-02')&p.failure.eq(1)).sum()),conflicting_raw_rows=2,conflicting_timestamps=1)
    s['site_timing_uncertain_products']=int(p.site_timing_uncertain.sum());s['excluded_other_recipe_intervals']=int(p.quality_flags.fillna('').str.contains('其他配方').sum());s['excluded_boundary_intervals']=int(p.label_valid.eq(0).sum())-s['excluded_other_recipe_intervals']
    dump(s,analysis/'汇总.json');dump(s['new_data'],analysis/'新增数据核对.json')
    source=json.loads((analysis/'来源与现场确认.json').read_text('utf-8'));source['site_reply_1113']=cfg['site_reply_1113'];source['live_tag_screenshot']='2026-11-16 user-provided interface screenshot only; no historical sensor backfill'
    dump(source,analysis/'来源与现场确认.json')
    candidates=json.loads((analysis/'历史8处候选核对.json').read_text('utf-8'))
    for c in candidates:
        if c['candidate_id']=='R004':c['updated_assessment']='现场确认9/29已换枪，Excel漏记'
        if c['candidate_id']=='R008':c['updated_assessment']='10/15早段低压后重启线索；实际更换在中午，不额外计更换'
        c['actual_window_confirmed']=bool(c.get('record_ids'))
    dump(candidates,analysis/'历史8处候选核对.json');raw.write_csv(pd.DataFrame(candidates),analysis/'历史8处候选核对.csv')
    # Differentiate an unmatched stop from a missing dated register entry.
    u=json.loads((analysis/'未登记低压停喷线索.json').read_text('utf-8'))
    for r in u:r['origin_label']='早段低压后停喷，未确认另换一次枪' if r['window_id']=='W105' else '连续低压后停喷，尚无实际更换登记'
    dump(u,analysis/'未登记低压停喷线索.json')
    e=load(analysis/'关注事件索引.csv',['start','end'])
    event_ix=e.index[e.event_id.eq('G010_W174')]
    for ix in event_ix:
        old=str(e.loc[ix,'product_ids']).split(';');e.loc[ix,'product_ids']=';'.join(dict.fromkeys([*old,*next_work.product_id]))
    for ix in next_work.index:
        old=p.loc[ix,'attention_event_ids'] if pd.notna(p.loc[ix,'attention_event_ids']) else ''
        p.loc[ix,'attention_event_ids']=';'.join(dict.fromkeys(filter(None,[*old.split(';'),'G010_W174'])))
    raw.write_csv(p,analysis/'产品级标签.csv')
    for r in u:e.loc[e.event_id.eq(r['event_id']),'origin_label']=r['origin_label']
    raw.write_csv(e,analysis/'关注事件索引.csv')
    # The unmodified original 28 sensor columns plus current labels are exported again.
    raw.export_excerpts(root,m,p,e,cfg,analysis)
    mp=load(output/'model_data/products.csv')[['product_id','cycle_id','split','supervised_product_eligible']]
    raw.write_csv(mp.merge(p,on='product_id',validate='one_to_one'),output/'model_data/products.csv')
    cycles=load(output/'model_data/electrode_cycles.csv')
    cycles.loc[cycles.start_event.eq('G010'),'note']=g10['site_note'];cycles.loc[cycles.end_event.eq('G010'),'end_note']=g10['site_note']
    raw.write_csv(cycles,output/'model_data/electrode_cycles.csv')
    return s

def figures(analysis,output):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.dates as md
    plt.rcParams.update({'font.family':'Microsoft YaHei','axes.unicode_minus':False,'font.size':10})
    folder=analysis/'图表';folder.mkdir(exist_ok=True)
    p=load(analysis/'产品级标签.csv',['start','end']);q=p[p.start.ge('2026-11-06')&p.start.lt('2026-11-11')&p.label_valid.eq(1)]
    fig,ax=plt.subplots(figsize=(13,4.4),layout='constrained');ax.scatter(q.end,q.voltage_mean,s=12,c=np.where(q.voltage_fail.eq(1),'#b64239','#356b92'))
    ax.axhline(51,c='#b64239',ls='--',lw=1)
    marks=[('2026-11-06 14:58:20','11/6结束生产后提前更换\n现场确认，分钟未知','#52745b'),('2026-11-09 13:30:19','11/9约13:30更换\n现场确认','#52745b'),('2026-11-10 13:34:43','11/10低压后停喷\n传感器线索，非确认更换','#aa7940')]
    for t,label,color in marks:
        t=pd.Timestamp(t);ax.axvline(t,c=color,ls=':',lw=1.3);right=t.day==10;ax.annotate(label,xy=(t,57),xytext=(-8 if right else 8,0),textcoords='offset points',ha='right' if right else 'left',va='top',fontsize=8,color=color)
    ax.set(ylim=(48.5,58),ylabel='完整产品平均电压 V',title='Booth2：11/6—11/10实际产品电压与维护记录')
    ax.xaxis.set_major_formatter(md.DateFormatter('%m-%d\n%H:%M'));ax.grid(axis='y',alpha=.2)
    fig.savefig(folder/'03_november_life.png',dpi=140);plt.close(fig)
    cycles=load(output/'model_data/electrode_cycles.csv',['start_lower','usable_start','usable_end']);fig,ax=plt.subplots(figsize=(13,6.5),layout='constrained');colors={'train':'#426d92','validation':'#b48b45','test':'#5a8b76'}
    for i,r in enumerate(cycles.itertuples()):
        ax.plot([r.usable_start,r.usable_end],[i,i],lw=7,c=colors[r.split],solid_capstyle='butt',alpha=.8,ls='--' if r.left_censored else '-')
        ax.text(r.usable_end,i,f'  {r.end_event if isinstance(r.end_event,str) else "观测结束"}',va='center',fontsize=8)
    ax.set_yticks(range(len(cycles)),[f'{r.cycle_id} {dict(train="训练",validation="验证",test="测试")[r.split]}' for r in cycles.itertuples()]);ax.invert_yaxis();ax.xaxis.set_major_formatter(md.DateFormatter('%m-%d'))
    ax.set(title='按电极安装／观察周期顺序划分；I001为传感器线索边界',xlabel='日期（2026年）；虚线为周期起点不完整的观察段');ax.grid(axis='x',alpha=.15)
    fig.savefig(folder/'04_split_cycles.png',dpi=140);plt.close(fig)
