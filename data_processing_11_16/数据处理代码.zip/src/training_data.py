"""Causal input tables and separately stored future targets. No fitted model."""
from pathlib import Path
import hashlib,json,io
import numpy as np
import pandas as pd
import data_io as raw
from common import load,dump,FMT,clean

END=pd.Timestamp('2026-11-15')

KINDS=['first_'+x for x in ['voltage','feedrate','pressure','any']]+['adjacent_two_'+x for x in ['voltage','feedrate','pressure','any']]

def epoch_seconds(series):
    # pandas can store datetime arrays in us, ms or ns; never assume the integer unit.
    return series.to_numpy(dtype='datetime64[s]').astype(np.int64)

def make_targets(features,p,cycles,clock,ev,records):
    targets=features[['anchor_id','timestamp','cycle_id','split']].copy().reset_index(drop=True)
    tt=epoch_seconds(targets.timestamp)
    for kind in KINDS:
        targets[kind+'_seconds']=np.nan
        for hours in [1,24]:targets[kind+f'_within_{hours}h']=pd.Series(pd.NA,index=targets.index,dtype='Int64')
    targets['observation_horizon_seconds']=0;targets['rul_strict_seconds']=np.nan;targets['rul_sensor_seconds']=np.nan
    targets['maintenance_time_lower_seconds']=np.nan;targets['maintenance_time_upper_seconds']=np.nan
    ts=clock.ts;gap_idx=np.flatnonzero(np.diff(ts)>2);gap_barriers=np.r_[ts[gap_idx]+1,ts[~clock.known]]
    for c in cycles.itertuples():
        hit=targets.cycle_id.eq(c.cycle_id);ix=np.flatnonzero(hit.to_numpy())
        if not len(ix):continue
        now=tt[ix];end=int(c.usable_end.value//10**9)
        bad=epoch_seconds(p[p.cycle_id.eq(c.cycle_id)&p.supervised_product_eligible.eq(0)].start)
        barriers=np.unique(np.r_[gap_barriers,bad,end]);pos=np.searchsorted(barriers,now,side='right');stop=barriers[np.minimum(pos,len(barriers)-1)]
        horizon=np.maximum(0,np.minimum(stop,end)-now);targets.loc[hit,'observation_horizon_seconds']=horizon
        for kind in KINDS:
            ends=np.sort(epoch_seconds(ev.loc[ev.cycle_id.eq(c.cycle_id)&ev.kind.eq(kind),'time']))
            if len(ends):
                j=np.searchsorted(ends,now,side='right');future=np.where(j<len(ends),ends[np.minimum(j,len(ends)-1)],np.iinfo(np.int64).max//2);delta=future-now
            else:delta=np.full(len(now),np.inf)
            observed=(delta<horizon)&(delta>0)
            targets.loc[hit,kind+'_seconds']=np.where(observed,delta,np.nan)
            for hours in [1,24]:
                window=hours*3600;outcome=np.where(observed&(delta<=window),1,np.where(horizon>window,0,np.nan))
                targets.loc[hit,kind+f'_within_{hours}h']=pd.array(outcome,dtype='Int64')
        if pd.notna(c.eol_endpoint):
            remaining=(c.eol_endpoint-targets.loc[hit,'timestamp']).dt.total_seconds();remaining=remaining.where(remaining>0)
            if c.eol_strict_observed:targets.loc[hit,'rul_strict_seconds']=remaining
            if c.eol_sensor_observed:targets.loc[hit,'rul_sensor_seconds']=remaining
        if isinstance(c.end_event,str) and c.end_event and c.end_event!='I001':
            rec=next(g for g in records if g['record_id']==c.end_event)
            targets.loc[hit,'maintenance_time_lower_seconds']=(rec['action_time_lower']-targets.loc[hit,'timestamp']).dt.total_seconds()
            targets.loc[hit,'maintenance_time_upper_seconds']=(rec['action_time_upper']-targets.loc[hit,'timestamp']).dt.total_seconds()
    return targets

def build_cycles(p,records,audit,clock):
    rows=[]
    # A sensor-only reset on Nov10 is NOT a confirmed replacement action.
    reset=audit[audit.window_id.eq('W184')].iloc[0]
    bounds=[dict(id='START',lo=pd.Timestamp('2026-09-12'),hi=pd.Timestamp('2026-09-12'),kind='left_censored',note='已安装电极，起点不在数据内')]
    for g in records:
        bounds.append(dict(id=g['record_id'],lo=g['action_time_lower'],hi=g['action_time_upper'],kind=g['action_type'],note=g['site_note']))
    bounds.append(dict(id='I001',lo=reset.start,hi=reset.end,kind='sensor_reset_unconfirmed',note='11/10连续4件低压后停喷并恢复；未取得当日实际更换登记。'))
    bounds.sort(key=lambda x:x['lo'])
    for i,b in enumerate(bounds):
        nxt=bounds[i+1] if i+1<len(bounds) else None
        lo=b['hi'];hi=nxt['lo'] if nxt else END
        q=p[p.start.gt(lo)&p.end.lt(hi)]
        # Entire installation periods belong to one split; physical serials can be reused.
        split='train' if b['lo']<pd.Timestamp('2026-10-20 14:20:49') else 'validation' if b['lo']<pd.Timestamp('2026-11-06 14:58:20') else 'test'
        ending=nxt['kind'] if nxt else 'right_censored'
        terminal=bool(nxt and ending in ['natural_eol','short_life_eol','low_voltage_then_replacement'])
        weak=bool(nxt and nxt['id']=='I001')
        before=q[q.label_valid.eq(1)]
        group=[]
        for r in reversed(list(before.itertuples())):
            if r.voltage_fail!=1:break
            group.append(r)
        if terminal or weak:
            # Prefer second consecutive low-product completion, not stop/restart time.
            ordered=list(reversed(group))
            if nxt and nxt['id']!='I001':
                rec=next(g for g in records if g['record_id']==nxt['id'])
                ww=audit[audit.window_id.isin(rec['supported_window_ids'].split(';'))]
                if len(ww):
                    member_ids=str(ww.iloc[0].low_product_ids).split(';')
                    ordered=list(q[q.product_id.isin(member_ids)&q.label_valid.eq(1)].sort_values('start').itertuples())
            endpoint=ordered[1].end if len(ordered)>=2 else pd.NaT
        else:endpoint=pd.NaT
        recorded_hours=np.nan
        if nxt and nxt['id']!='I001':recorded_hours=next(g for g in records if g['record_id']==nxt['id'])['working_hours']
        measured=clock.measure(lo,hi)
        # W104 endpoint precedes the interval which spans midnight; all leading failed products are in q.
        usable=q.label_valid.eq(1)&q.site_timing_uncertain.ne(1)
        rows.append(dict(cycle_id=f'L{i:03d}',split=split,start_event=b['id'],end_event=nxt['id'] if nxt else '',
          start_lower=b['lo'],start_upper=b['hi'],usable_start=lo,usable_end=hi,
          left_censored=int(i==0 or b['kind']=='sensor_reset_unconfirmed'),right_censored=int(nxt is None),
          preventive_end=int(ending=='preventive'),end_type=ending,end_evidence='sensor_only' if weak else 'site_or_register' if nxt else 'data_end',
          eol_endpoint=endpoint,eol_strict_observed=int(terminal and pd.notna(endpoint)),eol_sensor_observed=int(weak and pd.notna(endpoint)),
          product_count=len(q),eligible_products=int(usable.sum()),failure_products=int((q.failure.eq(1)&usable).sum()),voltage_failed_products=int((q.voltage_fail.eq(1)&usable).sum()),
          feed_failed_products=int((q.feedrate_fail.eq(1)&usable).sum()),pressure_failed_products=int((q.hopper_pressure_fail.eq(1)&usable).sum()),
          note=b['note'],end_note=nxt['note'] if nxt else '观测结束；没有未来故障标签',
          complete_installation_to_endpoint=int(i>0 and b['kind']!='sensor_reset_unconfirmed' and pd.notna(endpoint)),
          optimal_change_time_label_available=0,recorded_old_electrode_hours=recorded_hours,
          observed_on_hours=measured['on_hours'],unknown_clock_hours=measured['missing_hours'],
          working_hours_proxy_is_plc_counter=0))
    return pd.DataFrame(rows)

def prepare(root,analysis,output):
    out=output/'model_data';out.mkdir(exist_ok=True)
    p=load(analysis/'产品级标签.csv',['start','end','label_available_at']);m=load(analysis/'来源文件清单.csv',['time_start','time_end']).fillna({'zip_member':'','identical_bytes_to':''})
    from process_data import make_clock
    cfg=json.loads((analysis/'使用的参数.json').read_text('utf-8'));clock=make_clock(root,m,analysis,cfg)
    rs=json.loads((analysis/'Booth2换枪记录与窗口核对.json').read_text('utf-8'))
    for g in rs:
        for key in ['action_time_lower','action_time_upper']:g[key]=pd.to_datetime(g[key],format=FMT)
    audit=load(analysis/'停喷观察全量.csv',['start','end'])
    cycles=build_cycles(p,rs,audit,clock)
    p['cycle_id']='';p['split']='excluded';p['supervised_product_eligible']=p.label_valid.astype(int)
    for c in cycles.itertuples():
        hit=p.start.gt(c.usable_start)&p.end.lt(c.usable_end);p.loc[hit,'cycle_id']=c.cycle_id;p.loc[hit,'split']=c.split
    p.loc[p.cycle_id.eq('')|p.site_timing_uncertain.eq(1),'supervised_product_eligible']=0
    # No completed-product statistic is a same-product live input.
    raw.write_csv(p,out/'products.csv');raw.write_csv(cycles,out/'electrode_cycles.csv')
    raw.write_csv(pd.DataFrame(rs),out/'maintenance_events.csv')
    splits=cycles.groupby('split',sort=False).agg(cycles=('cycle_id','size'),eligible_products=('eligible_products','sum'),failed_products=('failure_products','sum'),voltage_failures=('voltage_failed_products','sum'),feedrate_failures=('feed_failed_products','sum'),pressure_failures=('pressure_failed_products','sum'),strict_eol_endpoints=('eol_strict_observed','sum'),sensor_only_endpoints=('eol_sensor_observed','sum')).reset_index()
    raw.write_csv(splits,out/'split_summary.csv')
    # Events for first failures and adjacent two failures by cause; batch information unavailable.
    events=[]
    for c in cycles.itertuples():
        q=p[p.cycle_id.eq(c.cycle_id)].sort_values('start')
        for cause,col in [('voltage','voltage_fail'),('feedrate','feedrate_fail'),('pressure','hopper_pressure_fail'),('any','failure')]:
            run=0;last=None
            for r in q.itertuples():
                if r.supervised_product_eligible and getattr(r,col)==1:
                    run=run+1 if last is not None and (r.start-last).total_seconds()<=1800 else 1;last=r.end
                    events.append(dict(event_id=f'F_{cause}_{r.product_id}',kind='first_'+cause,cycle_id=c.cycle_id,split=c.split,time=r.end,product_id=r.product_id,plc_trigger_confirmed=0))
                    if run==2:events.append(dict(event_id=f'T_{cause}_{r.product_id}',kind='adjacent_two_'+cause,cycle_id=c.cycle_id,split=c.split,time=r.end,product_id=r.product_id,plc_trigger_confirmed=0))
                else:run=0;last=None
    ev=pd.DataFrame(events);raw.write_csv(ev,out/'target_events.csv')
    minute_parts=[];feature_parts=[];target_parts=[];conflicts=[];daily_checks=[]
    physical=raw.PHYSICAL
    for day in sorted(p.start.dt.date.unique()):
        d,info=raw.load_day(root,m,day)
        if info['conflicting_rows']:
            conflicts.extend(d.loc[d.timestamp_conflict,['timestamp','source_id','source_row']].to_dict('records'))
        good=~d.timestamp_conflict
        # All duplicate-timestamp observations are excluded, not counted or averaged twice.
        d=d[good].set_index('timestamp').sort_index();d['cycle_id']='';d['split']='excluded'
        for c in cycles.itertuples():
            hit=(d.index>c.usable_start)&(d.index<c.usable_end);d.loc[hit,'cycle_id']=c.cycle_id;d.loc[hit,'split']=c.split
        d['excluded_product']=False
        for r in p[(p.start.dt.date==day)&p.supervised_product_eligible.eq(0)].itertuples():
            d.loc[(d.index>=r.start)&(d.index<=r.end),'excluded_product']=True
        # Every minute is reindexed; absent intervals stay NaN, never a synthetic zero.
        av=d[physical].resample('1min').mean();counts=d.Voltage.resample('1min').count()
        last=d[physical].resample('1min').last().add_suffix('_last')
        minute=pd.concat([av,last],axis=1);minute['observed_points']=counts
        minute['cycle_id']=d.cycle_id.resample('1min').agg(lambda x:x.iloc[-1] if len(x) and x.nunique()==1 and x.iloc[-1] else '')
        minute['split']=d.split.resample('1min').agg(lambda x:x.iloc[-1] if len(x) and x.nunique()==1 else 'excluded')
        minute['excluded_points']=d.excluded_product.resample('1min').sum()
        minute['timestamp']=minute.index+pd.Timedelta(seconds=59);minute['available_at']=minute.timestamp
        minute['quality_valid']=((minute.observed_points==60)&minute.cycle_id.ne('')&minute.excluded_points.eq(0)).astype(int)
        minute_parts.append(minute.reset_index(drop=True))
        # Rolling features are trailing observed samples, reset at observation gaps and maintenance boundaries.
        breaks=(d.index.to_series().diff().dt.total_seconds().gt(2)|d.cycle_id.ne(d.cycle_id.shift())|d.excluded_product.ne(d.excluded_product.shift())).cumsum()
        d['segment_id']=breaks.to_numpy()
        anchors=d[(d.index.second%10==0)&(d.Station_1.abs().gt(50)|d.Station_2.abs().gt(50))&d.Current.gt(100)&d.Power.gt(5)&d.cycle_id.ne('')&~d.excluded_product]
        parts=[]
        for _,z in d.groupby('segment_id',sort=False):
            ix=anchors.index.intersection(z.index)
            if len(ix)==0:continue
            rolling=z[physical].rolling('60s',min_periods=1)
            f=rolling.mean().loc[ix].add_suffix('_mean60s')
            f=pd.concat([z.loc[ix,physical].add_suffix('_last'),f],axis=1)
            f['Voltage_std60s']=rolling.std().loc[ix,'Voltage']
            f['history_points60s']=rolling.count().loc[ix,'Voltage']
            f['cycle_id']=z.loc[ix,'cycle_id'];f['split']=z.loc[ix,'split'];f['timestamp']=ix
            f['anchor_id']=['A'+str(int(t.value//10**9)) for t in ix]
            parts.append(f.reset_index(drop=True))
        if not parts:continue
        features=pd.concat(parts,ignore_index=True);feature_parts.append(features)
        targets=make_targets(features,p,cycles,clock,ev,rs)
        target_parts.append(targets)
        daily_checks.append(dict(day=str(day),rows=len(d),conflicting_rows=info['conflicting_rows'],anchors=len(features)))
        if len(daily_checks)%8==0:print('Causal feature days:',len(daily_checks),flush=True)
    features=pd.concat(feature_parts,ignore_index=True);targets=pd.concat(target_parts,ignore_index=True)
    assert features.anchor_id.is_unique and features.anchor_id.equals(targets.anchor_id)
    # cycle_id/split are offline bookkeeping keys, never numeric model inputs.
    features.to_csv(out/'features_10s.csv.gz',index=False,encoding='utf-8-sig',date_format=FMT,float_format='%.8g',compression='gzip')
    targets.to_csv(out/'targets_10s.csv.gz',index=False,encoding='utf-8-sig',date_format=FMT,float_format='%.12g',compression='gzip')
    minutes=pd.concat(minute_parts,ignore_index=True).set_index('timestamp').sort_index()
    grid=pd.date_range('2026-09-12 00:00:59','2026-11-14 23:59:59',freq='1min')
    minutes=minutes.reindex(grid);minutes.index.name='timestamp';minutes['available_at']=minutes.index
    minutes['quality_valid']=minutes.quality_valid.fillna(0).astype(int);minutes['observed_points']=minutes.observed_points.fillna(0).astype(int)
    minutes.to_csv(out/'sensor_minutes.csv.gz',encoding='utf-8-sig',date_format=FMT,float_format='%.8g',compression='gzip')
    # A strict example forecast index: 24h past -> next 60min; both must stay in one split/cycle.
    ids=minutes.cycle_id.fillna('');quality=minutes.quality_valid.eq(1)
    past_ok=quality.rolling(1440,min_periods=1440).sum().eq(1440)
    future_ok=quality.shift(-1).iloc[::-1].rolling(60,min_periods=60).sum().iloc[::-1].eq(60)
    same=(ids.eq(ids.shift(1439))&ids.eq(ids.shift(-60))&ids.ne(''))
    candidate=pd.DataFrame(dict(anchor_time=minutes.index,cycle_id=ids.to_numpy(),split=minutes.split.fillna('excluded').to_numpy(),past_24h_complete=past_ok.astype(int).to_numpy(),future_60min_complete=future_ok.astype(int).to_numpy(),same_cycle=same.astype(int).to_numpy()))
    candidate=candidate[candidate.anchor_time.dt.minute.eq(59)&candidate.cycle_id.ne('')]
    candidate['strict_eligible']=(candidate.past_24h_complete.eq(1)&candidate.future_60min_complete.eq(1)&candidate.same_cycle.eq(1)).astype(int)
    raw.write_csv(candidate,out/'forecast_windows.csv')
    raw.write_csv(pd.DataFrame(daily_checks),analysis/'特征逐日核查.csv');raw.write_csv(pd.DataFrame(conflicts),analysis/'冲突时间点.csv')
    result=dict(cycles=len(cycles),split_summary=clean(splits.to_dict('records')),feature_anchors=len(features),minute_rows=len(minutes),forecast_windows=len(candidate),strict_forecast_windows=int(candidate.strict_eligible.sum()),
      strict_rul_anchors=int(targets.rul_strict_seconds.notna().sum()),weak_rul_anchors=int(targets.rul_sensor_seconds.notna().sum()),confirmed_actions=len(rs),
      endpoint_policy='Strict RUL=second consecutive low product completion before site/register-backed terminal replacement. Sensor-only Nov10 endpoint separate. Preventive changes censor natural EOL.',
      input_columns=[x for x in features.columns if x not in ['anchor_id','timestamp','cycle_id','split']],models_trained=False,optimal_maintenance_labels_available=False,
      nov9_voltage_failures=int(p[p.start.between('2026-11-09','2026-11-09 23:59:59')].voltage_fail.eq(1).sum()),
      target_non_null={k:int(targets[k].notna().sum()) for k in targets if k.endswith('_seconds')},
      zero_positive_cause_warning='Pressure/feed failures are sparse; see split_summary. Do not infer performance from anchor count.')
    dump(result,analysis/'训练数据准备.json');dump(result,out/'data_manifest.json')
    summary=json.loads((analysis/'汇总.json').read_text('utf-8'));summary.update(training_data=result,excel_recorded_changes=sum(g['record_id'].startswith('G') for g in rs),site_added_changes=sum(g['record_id'].startswith('S') for g in rs));dump(summary,analysis/'汇总.json')
    return result

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);a.add_argument('--analysis',type=Path,required=True);a.add_argument('--output',type=Path,required=True);v=a.parse_args();prepare(v.root,v.analysis,v.output)
