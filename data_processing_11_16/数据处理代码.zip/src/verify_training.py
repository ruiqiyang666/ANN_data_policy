"""Check split isolation, target censoring, online input causality and delivery counts."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import data_io as raw
from common import load,dump,FMT

def verify(root,analysis,output):
    d=output/'model_data';p=load(d/'products.csv',['start','end']);c=load(d/'electrode_cycles.csv',['usable_start','usable_end','eol_endpoint'])
    f=load(d/'features_10s.csv.gz',['timestamp']);t=load(d/'targets_10s.csv.gz',['timestamp']);ev=load(d/'target_events.csv',['time'])
    attention=load(output/'label_samples.csv');s=json.loads((analysis/'汇总.json').read_text('utf-8'))
    assert len(p)==s['products']==s['normal_products']+s['failed_products']+s['unknown_products']
    assert p.product_id.is_unique and attention.sample_id.is_unique and f.anchor_id.is_unique
    assert attention[attention.failure.eq(1)].sample_id.tolist()==p[p.failure.eq(1)].product_id.tolist()
    assert attention.loc[attention.label_valid.eq(0),'failure'].isna().all()
    assert f[['anchor_id','cycle_id','split']].equals(t[['anchor_id','cycle_id','split']]) and f.timestamp.equals(t.timestamp)
    assert f.groupby('cycle_id').split.nunique().eq(1).all() and p[p.cycle_id.notna()].groupby('cycle_id').split.nunique().eq(1).all()
    assert f.timestamp.dt.second.mod(10).eq(0).all()
    assert np.isfinite(f.filter(regex='_last$').to_numpy(dtype=float)).all()
    approved=json.loads((d/'data_manifest.json').read_text('utf-8'))['input_columns']
    assert set(f)-{'anchor_id','timestamp','cycle_id','split'}==set(approved)
    assert all(not any(bad in col.lower() for bad in ['failure','rul','eol','gun_age','cause','working_hours']) for col in approved)
    for r in c.itertuples():
        q=f[f.cycle_id.eq(r.cycle_id)];assert q.timestamp.gt(r.usable_start).all() and q.timestamp.lt(r.usable_end).all()
        if r.preventive_end or r.right_censored or r.end_type=='replacement_after_reported_damage':assert t.loc[t.cycle_id.eq(r.cycle_id),'rul_strict_seconds'].isna().all()
        if r.eol_strict_observed:
            q=t[t.cycle_id.eq(r.cycle_id)&t.rul_strict_seconds.notna()]
            assert np.allclose((r.eol_endpoint-q.timestamp).dt.total_seconds(),q.rul_strict_seconds,atol=1e-7)
    # Every generated next-event label points to an event from its own cycle and set.
    for kind in ['first_'+x for x in ['voltage','feedrate','pressure','any']]+['adjacent_two_'+x for x in ['voltage','feedrate','pressure','any']]:
        q=t[t[kind+'_seconds'].notna()].copy();assert q[kind+'_seconds'].gt(0).all() and q[kind+'_seconds'].lt(q.observation_horizon_seconds).all()
        q['end']=q.timestamp+pd.to_timedelta(q[kind+'_seconds'],unit='s')
        allowed=set((r.cycle_id,r.split,r.time) for r in ev[ev.kind.eq(kind)].itertuples())
        assert all((r.cycle_id,r.split,r.end) in allowed for r in q.itertuples())
        for hours in [1,24]:
            v=t[kind+f'_within_{hours}h'];assert v.dropna().isin([0,1]).all()
            assert t.loc[v.eq(0),'observation_horizon_seconds'].gt(hours*3600).all()
            assert t.loc[v.eq(1),kind+'_seconds'].le(hours*3600).all()
    # Independently reconstruct trailing input statistics at deterministic sampled anchors.
    m=load(analysis/'来源文件清单.csv',['time_start','time_end']).fillna({'zip_member':'','identical_bytes_to':''});checks=0
    examples=f.iloc[np.unique(np.linspace(0,len(f)-1,12,dtype=int))]
    for day,anchors in examples.groupby(examples.timestamp.dt.date):
        original,_=raw.load_day(root,m,day);original=original[~original.timestamp_conflict].set_index('timestamp')
        for _,r in anchors.iterrows():
            cyc=c[c.cycle_id.eq(r.cycle_id)].iloc[0];z=original[(original.index>cyc.usable_start)&(original.index<=r.timestamp)].copy()
            excluded=p[p.start.dt.date.eq(day)&p.supervised_product_eligible.eq(0)]
            for bad in excluded.itertuples():z.loc[(z.index>=bad.start)&(z.index<=bad.end),'exclude']=True
            if 'exclude' in z:
                badtime=z.index[z.exclude.fillna(False)].max() if z.exclude.fillna(False).any() else pd.NaT
                if pd.notna(badtime):z=z[z.index>badtime]
            gaps=z.index.to_series().diff().dt.total_seconds().gt(2)
            if gaps.any():z=z[z.index>=z.index[gaps].max()]
            z=z[z.index>r.timestamp-pd.Timedelta(seconds=60)]
            for col in raw.PHYSICAL:
                assert np.isclose(z[col].iloc[-1],r[col+'_last'],atol=1e-5,rtol=2e-7),('last',r.anchor_id,col)
                assert np.isclose(z[col].mean(),r[col+'_mean60s'],atol=1e-5,rtol=2e-7),('mean',r.anchor_id,col)
            assert len(z)==r.history_points60s;checks+=1
    records=load(d/'maintenance_events.csv',['date','source_date']);assert len(records)==12
    g=records[records.record_id.eq('G008')].iloc[0];assert g.date==pd.Timestamp('2026-10-28') and g.source_date==pd.Timestamp('2026-10-29')
    assert records[records.record_id.eq('G006')].supported_window_ids.iloc[0]=='W108'
    assert 'I001' not in set(records.record_id)
    assert p[p.start.dt.date.eq(pd.Timestamp('2026-11-09').date())].voltage_fail.eq(1).sum()==0
    z=np.load(analysis/'传感器计时与转台状态.npz');ix=np.searchsorted(z['timestamp_seconds'],pd.Timestamp('2026-11-06 18:19:51').value//10**9);assert not z['known'][ix]
    assert p.loc[p.product_id.eq('N000499'),'supervised_product_eligible'].iloc[0]==0
    products_by_split=p[p.supervised_product_eligible.eq(1)].groupby('split').product_id.count().to_dict()
    positives={}
    for split,q in t.groupby('split'):
        positives[split]={k:int(q[k].eq(1).sum()) for k in q if k.endswith('_within_1h')}
    result=dict(input_target_anchors=len(f),all_anchors_one_to_one=True,whole_cycles_not_split=True,inputs_have_no_future_labels=True,
      independently_recalculated_causal_anchors=checks,all_future_targets_match_same_cycle_events=True,
      negative_event_targets_require_full_future_observation=True,preventive_change_not_labeled_natural_eol=True,
      site_date_and_no_duplicate_action_verified=True,source_timestamp_conflict_masked=True,
      eligible_products_by_split=products_by_split,positive_anchor_counts_1h=positives,models_trained=False,
      browser_visual_review_performed=False,page_check='Separate offline JavaScript/DOM function check; not an actual browser render')
    dump(result,analysis/'训练数据验证.json');print(json.dumps(result,ensure_ascii=False,indent=2));return result

if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);a.add_argument('--analysis',type=Path,required=True);a.add_argument('--output',type=Path,required=True);v=a.parse_args();verify(v.root,v.analysis,v.output)
