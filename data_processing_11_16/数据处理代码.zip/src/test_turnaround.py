import unittest,json
from pathlib import Path
import pandas as pd
import numpy as np
import data_io as raw
from prepare_turnaware import turnaware

class CompleteCycleTests(unittest.TestCase):
 def frame(self):
  n=85;d=pd.DataFrame({c:np.zeros(n) for c in raw.PHYSICAL})
  d['timestamp']=pd.date_range('2026-09-14 12:00:00',periods=n,freq='s');d['source_id']='synthetic';d['source_row']=np.arange(n)+2;d['timestamp_conflict']=False
  d['Current']=550.;d['Power']=30.;d['Feedrate_1']=10.;d['Press._Hopper_1']=210.;d['Voltage']=54.;d.loc[10:74,'Station_1']=888.;d.loc[44,'Station_1']=1.;d.loc[44:74,'Voltage']=50.
  return d
 def cfg(self):return json.loads(Path(__file__).with_name('config.json').read_text('utf-8'))
 def test_two_halves_are_one_product_with_whole_mean(self):
  d=self.frame();r,_=turnaware(d,self.cfg());self.assertEqual(len(r),1);self.assertEqual(r[0]['duration_seconds'],65);self.assertEqual(r[0]['turnaround_points'],1);self.assertEqual(r[0]['voltage_fail'],0);self.assertAlmostEqual(r[0]['voltage_mean'],d.loc[10:74,'Voltage'].mean())
 def test_power_loss_is_not_a_turnaround(self):
  d=self.frame();d.loc[44,'Current']=0;r,_=turnaware(d,self.cfg());self.assertEqual(len(r),2)
 def test_other_table_activity_prevents_join(self):
  d=self.frame();d.loc[44,'Station_2']=888;r,_=turnaware(d,self.cfg());self.assertEqual(len(r),2)
 def test_long_stationary_gap_is_not_joined(self):
  d=self.frame();d.loc[44:46,'Station_1']=0;r,_=turnaware(d,self.cfg());self.assertEqual(len(r),2)
 def test_clock_hour_is_not_an_exclusion(self):
  d=self.frame();d['timestamp']=pd.date_range('2026-10-05 00:37:00',periods=len(d),freq='s');r,_=turnaware(d,self.cfg());self.assertEqual(r[0]['label_valid'],1)

if __name__=='__main__':unittest.main()
