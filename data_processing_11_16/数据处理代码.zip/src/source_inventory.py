"""Extend a versioned source manifest without changing source IDs or raw files."""
from pathlib import Path
import shutil,hashlib,io
import pandas as pd
import numpy as np
import data_io as raw
from common import load,FMT,dump
from process_data import make_clock

def seed(root,previous,dest,analysis,cfg):
    dest.mkdir(parents=True,exist_ok=True);analysis.mkdir(parents=True,exist_ok=True)
    for name in ['来源文件清单.csv','每日数据检查.csv','日内采样缺口.csv','分段参数敏感性.csv','规则来源核对.json','设备带电状态区间.csv','主数据电压分钟走势.csv','新增数据核对.json','产品级标签.csv','历史8处候选核对.csv','关注事件索引.csv']:
        shutil.copy2(previous/name,dest/name)
    shutil.copytree(previous/'参考样本',dest/'参考样本',dirs_exist_ok=True)
    manifest=load(dest/'来源文件清单.csv').fillna('');existing=set(manifest.container);seen={r.sha256:r.source_id for r in manifest.itertuples()};last=max(int(s[1:]) for s in manifest.source_id);rows=[]
    for folder in ['20261102-20261107','20261109-20261114']:
        for file in sorted((root/folder).rglob('*.csv')):
            container=file.relative_to(root).as_posix()
            if container in existing:continue
            b=file.read_bytes();sha=hashlib.sha256(b).hexdigest();d=pd.read_csv(io.BytesIO(b),sep=';',skipinitialspace=True,usecols=['Date-Time']);t=pd.to_datetime(d['Date-Time'],format=FMT,errors='raise');last+=1
            rows.append(dict(data_stream='main',container=container,zip_member='',source_id=f'S{last:04d}',bytes=len(b),sha256=sha,rows=len(d),time_start=t.min().strftime(FMT),time_end=t.max().strftime(FMT),invalid_timestamps=0,out_of_order_steps=int(t.diff().dt.total_seconds().lt(0).sum()),identical_bytes_to=seen.get(sha,'')));seen.setdefault(sha,f'S{last:04d}')
    manifest=pd.concat([manifest,pd.DataFrame(rows)],ignore_index=True);raw.write_csv(manifest,dest/'来源文件清单.csv')
    manifest=load(dest/'来源文件清单.csv',['time_start','time_end']).fillna({'zip_member':'','identical_bytes_to':''})
    clock=make_clock(root,manifest,analysis,cfg);ts=clock.ts;on=clock.powered
    starts=np.r_[0,np.flatnonzero((np.diff(ts)>2)|(np.diff(on.astype(int))!=0))+1];ends=np.r_[starts[1:]-1,len(ts)-1]
    state=pd.DataFrame([dict(start=pd.Timestamp(ts[a],unit='s'),end=pd.Timestamp(ts[b],unit='s'),powered=bool(on[a]),duration_seconds=int(ts[b]-ts[a]+1)) for a,b in zip(starts,ends)])
    raw.write_csv(state,dest/'设备带电状态区间.csv')
    old=load(previous/'停喷观察全量.csv',['start','end']);template=old.iloc[0].to_dict();lookup={r.start:r for r in old.itertuples()};num=max(int(s[1:]) for s in old.window_id);windows=[]
    for a,b in zip(starts,ends):
        start=pd.Timestamp(ts[a],unit='s');end=pd.Timestamp(ts[b],unit='s')
        if on[a] or start<pd.Timestamp(cfg['analysis_start']):continue
        if start in lookup:r=old[old.start.eq(start)].iloc[0].to_dict()
        else:
            num+=1;r=dict(template);r.update(window_id=f'W{num:03d}',candidate_id='')
        r.update(start=start,end=end,resume_at=pd.Timestamp(ts[b+1],unit='s') if b+1<len(ts) else pd.NaT,duration_seconds=int(ts[b]-ts[a]+1),adjacent_power_boundaries=bool(a>0 and b+1<len(ts) and on[a-1] and on[b+1] and ts[a]-ts[a-1]<=2 and ts[b+1]-ts[b]<=2),evidence_available_at=pd.Timestamp(ts[b+1],unit='s') if b+1<len(ts) else pd.NaT)
        for c in ['pre_product_ids','post_product_ids','product_ids','record_ids','low_product_ids']:r[c]=''
        windows.append(r)
    raw.write_csv(pd.DataFrame(windows).sort_values('start'),dest/'停喷观察全量.csv')
    return dest
