"""Reproduce full-cycle labels and the offline report without editing raw inputs."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,tempfile
from prepare_turnaware import prepare
from process_data import run
from finalize_analysis import finish
from verify_complete_cycles import verify
from build_bundle import build
from source_inventory import seed
from training_data import prepare as training_prepare
from finalize_delivery import finish as delivery_finish,figures
from verify_training import verify as verify_training
from write_docs import write as write_docs

def main():
 a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);a.add_argument('--previous-analysis',type=Path,required=True,help='11_10 本地核查材料; needed for original P lineage');a.add_argument('--gun-records',type=Path,required=True);a.add_argument('--output',type=Path,required=True);v=a.parse_args()
 src=Path(__file__).resolve().parent;out=v.output.resolve()
 if out.exists() and any(out.iterdir()):raise FileExistsError('Use a new empty output folder')
 out.mkdir(parents=True,exist_ok=True);analysis=out/'本地核查材料';cfg=json.loads((src/'config.json').read_text('utf-8'))
 with tempfile.TemporaryDirectory(prefix='input_',dir=out) as tmp:
  temp=Path(tmp);prior=seed(v.root,v.previous_analysis,temp/'seed',analysis,cfg);base=temp/'base';base.mkdir()
  cfg=prepare(v.root,prior,base,analysis,cfg)
  run(v.root,base,v.gun_records,analysis,cfg);finish(v.root,base,analysis,cfg)
 verify(v.root,analysis)
 training_prepare(v.root,analysis,out)
 delivery_finish(v.root,analysis,out,cfg)
 subprocess.run([sys.executable,'-B',str(src/'make_review.py'),'--output',str(analysis)],check=True)
 figures(analysis,out)
 build(analysis,out)
 verify_training(v.root,analysis,out)
 write_docs(out)
 shutil.copytree(src,out/'src',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 print('Finished data processing only:',out)

if __name__=='__main__':main()
