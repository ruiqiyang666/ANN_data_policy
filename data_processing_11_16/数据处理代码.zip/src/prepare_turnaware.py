"""Rebuild intervals from immutable raw CSVs, including observed turnarounds."""
from pathlib import Path
import argparse,hashlib,json,shutil
import numpy as np
import pandas as pd
import data_io as raw
from common import load,dump,clean,FMT

def spans(mask,ts):
 gap=np.diff(ts)>2
 return zip(np.flatnonzero(mask&np.r_[True,~mask[:-1]|gap]),np.flatnonzero(mask&np.r_[~mask[1:]|gap,True]))

def turnaware(d,cfg,reference=False):
 ts=d.timestamp.to_numpy(dtype='datetime64[s]').astype('int64');changed=d.copy();bridges=[]
 for st in [1,2]:
  active=d[f'Station_{st}'].abs().gt(50).to_numpy();other=d[f'Station_{3-st}'].abs().gt(50).to_numpy();fill=active.copy()
  for lo,hi in spans(~active,ts):
   if lo==0 or hi==len(ts)-1 or not active[lo-1] or not active[hi+1]:continue
   if ts[hi+1]-ts[lo-1]-1>cfg['turnaround_max_seconds'] or np.diff(ts[lo-1:hi+2]).max()>2 or other[lo:hi+1].any():continue
   z=d.iloc[lo:hi+1]
   gate=z.Voltage.gt(40).all() if reference else (z.Current.gt(100)&z.Power.gt(5)&(z.Feedrate_1.gt(0)|z.Feedrate_2.gt(0))).all()
   if not gate:continue
   fill[lo:hi+1]=True;bridges.append(dict(station=st,start=d.timestamp.iloc[lo],end=d.timestamp.iloc[hi],observed_points=hi-lo+1))
  changed[f'Station_{st}']=np.where(fill,100.,0.)
 rows=raw.extract_products(changed,cfg)
 for r in rows:
  r['duration_seconds']=int((r['end']-r['start']).total_seconds()+1)
  b=[x for x in bridges if x['station']==r['station'] and x['start']>=r['start'] and x['end']<=r['end']]
  r['turnaround_points']=sum(x['observed_points'] for x in b);r['turnaround_times']=';'.join(x['start'].strftime(FMT) for x in b)
  flags=list(filter(None,r['quality_flags'].split(';')))
  if not cfg['standard_duration_min']<=r['duration_seconds']<=cfg['standard_duration_max']:flags.append('其他配方测试工单（排除）' if r['duration_seconds']>85 else '加工边界不完整（排除）')
  if not reference and r['start'].day==20 and r['start'].month==9 and '加工时长待现场核实' in flags:flags[flags.index('加工时长待现场核实')]='9/20特殊长周期（排除）'
  r['quality_flags']=';'.join(flags);r['label_valid']=int(not flags)
  if flags:r['failure']=None;r['failure_type']='unknown'
 return rows,bridges

def prepare(root,previous,base,out,cfg):
 base.mkdir(parents=True,exist_ok=True);out.mkdir(parents=True,exist_ok=True)
 names=['来源文件清单.csv','每日数据检查.csv','日内采样缺口.csv','分段参数敏感性.csv','规则来源核对.json','设备带电状态区间.csv','主数据电压分钟走势.csv','新增数据核对.json']
 for name in names:
  if (previous/name).exists():shutil.copy2(previous/name,base/name)
 shutil.copytree(previous/'参考样本',base/'参考样本',dirs_exist_ok=True)
 if cfg.get('reuse_clock_cache',False):
  for name in ['传感器计时与转台状态.npz','传感器计时来源校验.json']:shutil.copy2(previous/name,out/name)
 old=load(previous/'产品级标签.csv',['start','end']);m=load(base/'来源文件清单.csv',['time_start','time_end']).fillna({'zip_member':'','identical_bytes_to':''})
 days=sorted(set(m.loc[m.data_stream.eq('main')&m.time_start.ge(cfg['analysis_start'])&m.time_start.lt(cfg['analysis_end_exclusive']),'time_start'].dt.date))
 rows=[];all_bridges=[];night=[];baselines=[];sensitivity={k:dict(intervals=0,short=0,long=0) for k in [1,2,3]}
 for i,day in enumerate(days,1):
  # Byte verification before any numerical parsing.
  for s in m[m.data_stream.eq('main')&m.time_start.dt.date.eq(day)&m.rows.gt(0)&m.identical_bytes_to.eq('')].to_dict('records'):
   assert hashlib.sha256(raw.payload(root,s)).hexdigest()==s['sha256']
  d,info=raw.load_day(root,m,day) # conflicting timestamps remain flagged; affected products are ineligible
  q,b=turnaware(d,cfg);rows.extend(q);all_bridges.extend(b)
  for limit in [1,2,3]:
   test=q if limit==cfg['turnaround_max_seconds'] else turnaware(d,dict(cfg,turnaround_max_seconds=limit))[0]
   sensitivity[limit]['intervals']+=len(test);sensitivity[limit]['short']+=sum(x['duration_seconds']<55 for x in test);sensitivity[limit]['long']+=sum(x['duration_seconds']>85 for x in test)
  n=d[d.timestamp.dt.hour.lt(5)];quiet=n[n.Station_1.abs().le(50)&n.Station_2.abs().le(50)]
  if len(quiet):baselines.append(dict(day=str(day),points=len(quiet),station1_median=quiet.Station_1.median(),station1_p99=quiet.Station_1.quantile(.99),station2_median=quiet.Station_2.median(),station2_p99=quiet.Station_2.quantile(.99),current_median=quiet.Current.median(),power_median=quiet.Power.median()))
  if i%8==0:print('Rebuilt days:',i,'through',day,flush=True)
 p=pd.DataFrame(rows).sort_values(['start','station']).reset_index(drop=True);p['product_id']=[f'N{i+1:06d}' for i in range(len(p))]
 mapping=[];old_to_new={}
 for ix,r in p.iterrows():
  q=old[old.station.eq(r.station)&old.start.le(r.end)&old.end.ge(r.start)]
  p.loc[ix,'old_sample_ids']=';'.join(q.product_id)
  p.loc[ix,'legacy_sampling_review']=int(q.sampling_released.eq(1).any())
  for o in q.itertuples():mapping.append(dict(old_sample_id=o.product_id,sample_id=r.product_id,old_start=o.start,old_end=o.end,start=r.start,end=r.end));old_to_new[o.product_id]=r.product_id
  p.loc[ix,'power_episode_id']='';p.loc[ix,'power_episode_start']=pd.NaT;p.loc[ix,'seconds_since_power_on']=np.nan;p.loc[ix,'startup_review']=False;p.loc[ix,'production_control_transition']=False
 assert len(old_to_new)==len(old),'Unmapped old fragments require inspection'
 correction=old[old.product_id.eq('P003507')].iloc[0];new=p[p.product_id.eq(old_to_new['P003507'])].iloc[0]
 assert new.start==correction.start and new.end==correction.end and abs(new.pressure_mean-250.2)<1e-8
 raw.write_csv(pd.DataFrame([dict(turnaround_gap_seconds=k,**v,scope='2026-09-12 through 2026-11-01') for k,v in sensitivity.items()]),base/'分段参数敏感性.csv')
 override=next(iter(cfg['confirmed_product_overrides'].values()));cfg['confirmed_product_overrides']={new.product_id:override}
 p['dataset_eligible']=p.label_valid.astype(int);p['exclusion_reason']=p.quality_flags;p['origin_label']='';p['origin_evidence']='';p['cause_confirmed']=0;p['attention_event_ids']=''
 raw.write_csv(p,base/'产品级标签.csv');raw.write_csv(pd.DataFrame(mapping),out/'新旧产品编号对照.csv');raw.write_csv(pd.DataFrame(all_bridges),out/'换向低速点审查.csv');raw.write_csv(pd.DataFrame(baselines),out/'夜间静止基线.csv')
 def remap(value):return ';'.join(dict.fromkeys(old_to_new[x] for x in str(value).split(';') if x in old_to_new))
 audit=load(previous/'停喷观察全量.csv',['start','end','resume_at','evidence_available_at'])
 audit=audit.drop(columns=['previous_screen_reason','previous_candidate_kind'],errors='ignore')
 for ix,w in audit.iterrows():
  pre=p[p.end.lt(w.start)&p.end.ge(w.start-pd.Timedelta(hours=1))].tail(5);post=p[p.start.gt(w.end)&p.start.le(w.end+pd.Timedelta(hours=1))].head(5)
  audit.loc[ix,'pre_count']=len(pre);audit.loc[ix,'post_count']=len(post)
  for side,q in [('before',pre),('after',post)]:
   audit.loc[ix,side+'_voltage_median']=q.voltage_mean.median();audit.loc[ix,side+'_voltage_min']=q.voltage_mean.min()
  audit.loc[ix,'voltage_gain_v']=post.voltage_mean.median()-pre.voltage_mean.median()
  audit.loc[ix,'pre_product_ids']=';'.join(pre.product_id);audit.loc[ix,'post_product_ids']=';'.join(post.product_id);audit.loc[ix,'product_ids']=';'.join([*pre.product_id,*post.product_id])
 raw.write_csv(audit,base/'停复机全量审查.csv')
 cand=load(previous/'历史8处候选核对.csv',['start','end','resume_at','evidence_available_at'])
 for ix,r in cand.iterrows():
  w=audit[audit.window_id.eq(r.window_id)].iloc[0]
  for c in ['pre_count','post_count','before_voltage_median','after_voltage_median','before_voltage_min','after_voltage_min','voltage_gain_v','pre_product_ids','post_product_ids','product_ids']:cand.loc[ix,c]=w[c]
 raw.write_csv(cand,base/'换枪候选索引.csv')
 events=load(previous/'关注事件索引.csv',['start','end']);events=events[events.event_kind.isin(['product_failure','replacement_candidate'])].copy();events['product_ids']=events.product_ids.map(remap)
 covered=set(';'.join(events.loc[events.event_kind.eq('product_failure'),'product_ids']).split(';'))
 for i,r in enumerate(p[p.failure.eq(1)&~p.product_id.isin(covered)].itertuples(),1000):
  events=pd.concat([events,pd.DataFrame([dict(event_id=f'E{i}',event_kind='product_failure',start=r.start,end=r.end,event_time=r.end,product_ids=r.product_id,failed_product_count=1,origin_label='产品均值超标')])],ignore_index=True)
 raw.write_csv(events,base/'关注事件索引.csv')
 # Independently segment Booth1 using only its voltage, time and turntable signals.
 parts=[]
 for path in sorted((root/'Voltage Sample').glob('27_Oct_2026H*.csv')):
  d=pd.read_csv(path,sep=';',skipinitialspace=True,usecols=lambda c:c.strip() in ['Date-Time','Voltage','Station_1','Station_2']);d.columns=d.columns.str.strip();d['timestamp']=pd.to_datetime(d['Date-Time'],format=FMT);d['source_id']=path.name;d['source_row']=np.arange(len(d))+2;d['timestamp_conflict']=False
  # Neutral placeholders only support the shared interval function; no other Booth1 sensor is used.
  for c in raw.PHYSICAL:
   if c not in d:d[c]=0.
  d['Feedrate_1']=1.;parts.append(d)
 d=pd.concat(parts,ignore_index=True).sort_values('timestamp').reset_index(drop=True);ref,_=turnaware(d,cfg,reference=True);ref=pd.DataFrame(ref).sort_values('start');ref['reference_voltage_fail']=ref.voltage_fail.where(ref.label_valid.eq(1));raw.write_csv(ref,base/'参考样本/末期产品核对.csv')
 dump(dict(raw_sources_sha256_verified=True,old_fragments=len(old),new_intervals=len(p),turnaround_gaps=len(all_bridges),night_processing_review=int(p.quality_flags.str.contains('夜间').sum()),duration_review=int(p.quality_flags.str.contains('时长').sum()),numbering='N=new complete-cycle candidate; P=old fragment ID in crosswalk',no_interpolation=True),out/'产品分段核对.json')
 return cfg

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);a.add_argument('--previous',type=Path,required=True);a.add_argument('--base',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--config',type=Path,required=True);v=a.parse_args();cfg=prepare(v.root,v.previous,v.base,v.output,json.loads(v.config.read_text('utf-8')));v.config.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
