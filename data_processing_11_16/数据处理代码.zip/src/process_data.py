"""Booth2 product labels and record-backed maintenance windows. No models."""
from pathlib import Path
import argparse,hashlib,io,json,shutil
import numpy as np
import pandas as pd
import openpyxl
import data_io as raw
from common import FMT,load,clean,dump,bits,revise_products,shutdown_followup
import site_alignment

class Clock:
    def __init__(self,ts,powered,station_active=None,feed_active=None,working_voltage=None,known=None):
        self.ts=np.asarray(ts,dtype=np.int64);assert len(self.ts)==0 or np.all(np.diff(self.ts)>0)
        self.powered=np.asarray(powered,dtype=bool)
        self.known=np.ones(len(self.ts),bool) if known is None else np.asarray(known,dtype=bool)
        self.powered=self.powered&self.known
        self.prefix=np.r_[0,np.cumsum(self.powered,dtype=np.int64)]
        self.known_prefix=np.r_[0,np.cumsum(self.known,dtype=np.int64)]
        self.station=np.zeros(len(self.ts),bool) if station_active is None else np.asarray(station_active,dtype=bool)
        self.station_ts=self.ts[self.station]
        self.feed=np.zeros(len(self.ts),bool) if feed_active is None else np.asarray(feed_active,dtype=bool)
        self.voltage=np.zeros(len(self.ts),bool) if working_voltage is None else np.asarray(working_voltage,dtype=bool)
    def measure(self,start,end):
        lo=int(pd.Timestamp(start).value//10**9);hi=int(pd.Timestamp(end).value//10**9)
        if hi<=lo:return dict(on_hours=0.,observed_hours=0.,missing_hours=0.)
        l,r=np.searchsorted(self.ts,[lo,hi],side='left');known=int(self.known_prefix[r]-self.known_prefix[l])
        return dict(on_hours=float(self.prefix[r]-self.prefix[l])/3600,observed_hours=known/3600,missing_hours=float(hi-lo-known)/3600)
    def bounds(self,previous_day,stop):
        start=pd.Timestamp(previous_day);low=self.measure(start+pd.Timedelta(days=1),stop);high=self.measure(start,stop)
        return dict(on_min=low['on_hours'],on_max=high['on_hours'],missing_max=high['missing_hours'],possible_max=high['on_hours']+high['missing_hours'])
    def idle_context(self,stop,seconds=900):
        end=int(pd.Timestamp(stop).value//10**9);ix=np.searchsorted(self.station_ts,end)-1
        idle=float(end-self.station_ts[ix]-1) if ix>=0 else None
        l,r=np.searchsorted(self.ts,[end-seconds,end]);t=self.ts[l:r]
        gaps=np.diff(np.r_[end-seconds-1,t,end]);maxgap=int(gaps.max()) if len(gaps) else seconds+1
        power=float(self.powered[l:r].mean()) if r>l else 0.
        return dict(no_station_seconds=idle,last_station_active_at=pd.Timestamp(self.station_ts[ix],unit='s') if ix>=0 else None,
            idle_context_rows=int(r-l),idle_max_sampling_gap_seconds=maxgap,
            idle_powered_fraction=power,idle_feeding_fraction=float(self.feed[l:r].mean()) if r>l else 0.,
            idle_working_voltage_fraction=float(self.voltage[l:r].mean()) if r>l else 0.,
            standby_compatible=bool(idle is not None and idle>=seconds and maxgap<=2 and power>=.9))

def make_clock(root,m,out,cfg):
    cache=out/'传感器计时与转台状态.npz'
    if cache.exists():
        z=np.load(cache);return Clock(z['timestamp_seconds'],z['powered'],z['station_active'],z['feed_active'],z['working_voltage'],z['known'])
    arrays={k:[] for k in ['timestamp_seconds','powered','station_active','feed_active','working_voltage','known']};verified=0
    cols=['Date-Time','Current','Power','Voltage','Station_1','Station_2','Feedrate_1','Feedrate_2']
    for r in m[(m.data_stream=='main')&m.identical_bytes_to.eq('')&m.rows.gt(0)].to_dict('records'):
        if r['time_start']>=pd.Timestamp(cfg['analysis_end_exclusive']):continue
        content=raw.payload(root,r)
        if hashlib.sha256(content).hexdigest()!=r['sha256']:raise ValueError('Raw source changed: '+r['container'])
        d=pd.read_csv(io.BytesIO(content),sep=';',encoding='utf-8-sig',skipinitialspace=True,usecols=lambda c:c.strip() in cols);d.columns=d.columns.str.strip()
        for c in cols[1:]:d[c]=pd.to_numeric(d[c],errors='coerce')
        arrays['timestamp_seconds'].append(pd.to_datetime(d['Date-Time'],format=FMT).to_numpy(dtype='datetime64[s]').astype(np.int64))
        arrays['known'].append(d.Current.notna().to_numpy()&d.Power.notna().to_numpy())
        arrays['powered'].append((d.Current.gt(100)&d.Power.gt(5)).to_numpy())
        arrays['station_active'].append((d.Station_1.gt(50)|d.Station_2.gt(50)).to_numpy())
        arrays['feed_active'].append((d.Feedrate_1.gt(0)|d.Feedrate_2.gt(0)).to_numpy())
        arrays['working_voltage'].append(d.Voltage.gt(40).to_numpy());verified+=1
        if verified%150==0:print('Verified main source files:',verified,flush=True)
    arrays={k:np.concatenate(v) for k,v in arrays.items()};order=np.argsort(arrays['timestamp_seconds'],kind='stable')
    arrays={k:v[order] for k,v in arrays.items()}
    duplicate=pd.Series(arrays['timestamp_seconds']).duplicated(keep=False).to_numpy()
    arrays['known'][duplicate]=False;arrays['powered'][duplicate]=False
    keep=~pd.Series(arrays['timestamp_seconds']).duplicated(keep='first').to_numpy()
    arrays={k:v[keep] for k,v in arrays.items()};assert np.all(np.diff(arrays['timestamp_seconds'])>0)
    np.savez_compressed(cache,**arrays)
    dump(dict(main_asset='Booth2',main_sources_sha256_verified=verified,rows=len(order),counting_rule='Observed Current>100A AND Power>5kW points; one second per point. Missing or invalid state seconds remain unknown.',station_activity_rule='Either Station>50rpm, same analysis threshold as product segmentation; no-product waiting verified from the raw signal, not only product counts'),out/'传感器计时来源校验.json')
    return Clock(arrays['timestamp_seconds'],arrays['powered'],arrays['station_active'],arrays['feed_active'],arrays['working_voltage'],arrays['known'])

def gun_records(book,start,end,asset='Booth2'):
    w=openpyxl.load_workbook(book,read_only=True,data_only=True);s=w['新换枪记录'];all_rows=[];blank=0
    for rownum,row in enumerate(s.iter_rows(min_row=2,max_row=5000,max_col=7,values_only=True),2):
        if not any(v is not None for v in row):
            blank+=1
            if blank>=30:break
            continue
        blank=0
        if str(row[0]).strip().lower()!=asset.lower():continue
        all_rows.append(dict(source_row=rownum,date=pd.Timestamp(row[1]).normalize(),asset=asset,work_order=str(row[2]),old_serial=str(row[3]),ignitions=row[4],working_hours=float(row[5]),new_serial=str(row[6]),source_sheet='新换枪记录',source_cells=f'A{rownum}:G{rownum}'))
    w.close();all_rows.sort(key=lambda r:(r['date'],r['source_row']));records=[]
    for i,r in enumerate(all_rows):
        if start<=r['date']<end:
            previous=all_rows[i-1];records.append(dict(r,record_id=f'G{len(records)+1:03d}',previous_record_date=previous['date'],previous_source_row=previous['source_row'],previous_new_serial=previous['new_serial'],serial_chain_matches=previous['new_serial']==r['old_serial'],record_action_confirmed=True,date_alignment_accepted_by_site=True,time_precision='date_only',exact_change_time='',exact_time_confirmed=False))
    return records

def low_sequence_before_stop(p,stop,max_seconds=120):
    before=p[p.end.lt(stop)]
    result=dict(low_failed_products=0,low_product_ids='',finishing_normal_products=0,last_product_end=None,failure_stop_connected=False)
    if before.empty:return result
    i=len(before)-1;last=before.iloc[i];result['last_product_end']=last.end
    if (stop-last.end).total_seconds()>max_seconds:return result
    normal=0
    if last.label_valid==1 and last.failure==0:normal=1;i-=1
    if i<0:return result
    members=[];following=None
    while i>=0:
        r=before.iloc[i]
        if r.label_valid!=1 or r.voltage_fail!=1:break
        if following is not None and (following-r.end).total_seconds()>1800:break
        members.append(r.product_id);following=r.start;i-=1
    if len(members)>=2:
        result.update(low_failed_products=len(members),low_product_ids=';'.join(reversed(members)),finishing_normal_products=normal,failure_stop_connected=True)
    return result

def annotate_stops(p,audit,clock,cfg):
    a=audit.copy()
    if 'reason' in a:a=a.rename(columns={'reason':'previous_screen_reason','candidate_kind':'previous_candidate_kind'})
    rows=[]
    for r in a.to_dict('records'):
        r.update(low_sequence_before_stop(p,r['start'],cfg['maximum_failure_to_stop_seconds']))
        r.update(clock.idle_context(r['start'],cfg['idle_no_station_seconds']))
        overlap=int((p.start.le(r['end'])&p.end.ge(r['start'])).sum())
        r['site_rule_stop_eligible']=bool(r['failure_stop_connected'] and r['adjacent_power_boundaries'] and overlap==0)
        if r['failure_stop_connected']:kind='连续低压后停喷'
        elif r['standby_compatible']:kind='无转台加工等待至少15分钟后停喷'
        else:kind='其他停喷，原因未定'
        r.update(stop_class=kind,record_ids='',site_rule_window_supported=False,record_window_ambiguous=False,
            reason=(f"连续{r['low_failed_products']}件低压后停喷"+('，中间有1件正常收尾' if r['finishing_normal_products'] else '')) if r['failure_stop_connected'] else f"转台未加工约{r['no_station_seconds']/60:.1f}分钟，停前仍有工作电压／送料信号，符合待机特征" if r['standby_compatible'] else '保留停喷信号，未确定其原因')
        rows.append(r)
    return pd.DataFrame(rows)

def annotate_records(records,audit,clock,p):
    for i,g in enumerate(records):
        day=g['date'];end=day+pd.Timedelta(days=1)
        overlapping=audit[audit.start.lt(end)&audit.end.ge(day)]
        eligible=audit[audit.start.ge(day)&audit.start.lt(end)&audit.site_rule_stop_eligible]
        ids=eligible.window_id.tolist()
        mode='unique_site_rule' if len(ids)==1 else 'multiple_low_stop_windows' if len(ids)>1 else 'record_only_no_low_stop'
        g.update(match_state=mode,low_stop_window_ids=';'.join(ids),supported_window_ids=';'.join(ids) if len(ids)==1 else '',window_ids=';'.join(overlapping.window_id),sensor_window_supported_by_site_rule=len(ids)==1,illustration_window='',illustration_reason='',working_hours_conflict=False,working_hours_checkable=False,working_comparison_basis='date_bounds_only',counter_hypothesis='',candidate_working_hour_checks=[],date_bound_hours_conflict=False)
        if len(ids)==1:
            w=eligible.iloc[0];g.update(illustration_window=w.window_id,matched_start=w.start,matched_end=w.end)
        elif not ids:
            viable=overlapping[(overlapping.pre_count>=2)&(overlapping.post_count>=2)&overlapping.start.ge(day)&overlapping.duration_seconds.ge(60)].copy()
            if len(viable):
                viable['absolute_voltage_change']=viable.voltage_gain_v.abs();g['illustration_window']=viable.sort_values('absolute_voltage_change',ascending=False).iloc[0].window_id
                g['illustration_reason']='仅展示当天前后产品电压中位数变化较大的停喷段；不据此认定该段就是换枪'
        minimum=clock.measure(g['previous_record_date']+pd.Timedelta(days=1),day)
        maximum=clock.measure(g['previous_record_date'],end)
        g.update(observed_on_min_hours=minimum['on_hours'],observed_on_max_hours=maximum['on_hours'],unobserved_max_hours=maximum['missing_hours'],possible_on_max_hours=maximum['on_hours']+maximum['missing_hours'])
        if not g['serial_chain_matches']:
            g['working_hours_comparison']='前后枪号不衔接，缺少完整周期起点；不硬算寿命'
        elif i==0:
            g['working_hours_comparison']='周期起点早于数据起点，只列记录值'
        else:
            prev=records[i-1]
            if prev['match_state']=='unique_site_rule' and mode=='unique_site_rule':
                m=clock.measure(prev['matched_end']+pd.Timedelta(seconds=1),g['matched_start'])
                g.update(observed_on_min_hours=m['on_hours'],observed_on_max_hours=m['on_hours'],unobserved_max_hours=m['missing_hours'],possible_on_max_hours=m['on_hours']+m['missing_hours'],working_comparison_basis='between_rule_supported_windows',working_hours_checkable=True)
                h=g['working_hours'];lo=g['observed_on_min_hours'];hi=g['possible_on_max_hours']
                g['working_hours_conflict']=bool(h<lo-.005 or h>hi+.005)
                g['working_hours_comparison']='与已观察带电时长范围接近' if not g['working_hours_conflict'] else '带电估算与记录时长不一致，计时口径或对应仍需核实'
            else:
                g['working_hours_comparison']='前后两条登记未都定位到唯一窗口，周期起止不齐，不用时长强行选点'
                g['date_bound_hours_conflict']=bool(g['working_hours']<g['observed_on_min_hours']-.005 or g['working_hours']>g['possible_on_max_hours']+.005)
                if prev['match_state']=='unique_site_rule':
                    for w in eligible.itertuples():
                        cm=clock.measure(prev['matched_end']+pd.Timedelta(seconds=1),w.start)
                        g['candidate_working_hour_checks'].append(dict(window_id=w.window_id,previous_window=prev['supported_window_ids'],observed_on_hours=cm['on_hours'],unobserved_hours=cm['missing_hours'],possible_on_hours=cm['on_hours']+cm['missing_hours'],recorded_hours=g['working_hours'],proxy_conflict=bool(g['working_hours']<cm['on_hours']-.005 or g['working_hours']>cm['on_hours']+cm['missing_hours']+.005)))
        # Bind a record to all eligible windows, but never count one record twice.
        for wid in ids:
            ix=audit.index[audit.window_id.eq(wid)][0]
            audit.loc[ix,'record_ids']=g['record_id'];audit.loc[ix,'site_rule_window_supported']=len(ids)==1;audit.loc[ix,'record_window_ambiguous']=len(ids)>1
    return records,audit

def old_candidates(c,records,clock,audit):
    rows=[]
    for r in c.to_dict('records'):
        hit=audit[audit.start.eq(r['start'])&audit.end.eq(r['end'])]
        stop=hit.iloc[0] if len(hit) else None
        record_ids=str(stop.record_ids) if stop is not None and isinstance(stop.record_ids,str) else ''
        ref=next((g for g in records if g['record_id'] in record_ids.split(';')),None)
        if ref is None:ref=next((g for g in records if g['date']>=r['start'].normalize()),records[-1])
        status='低压后停喷线索，缺少同日换枪登记' if r['candidate_kind']=='after_voltage_failure' else '历史信号线索，不代表已换枪'
        if stop is not None and stop.site_rule_window_supported:status='换枪登记日＋连续低压后停喷，按现场规则支持此窗口'
        elif stop is not None and stop.record_window_ambiguous:status='当日有1条换枪登记，但有2个符合规则的窗口，待分辨'
        elif stop is not None and stop.standby_compatible:status='无转台加工等待超过15分钟，符合自动待机；不能据此认换枪'
        if r['candidate_id']=='R003':status='电压回升不足以认换枪；同日登记对应另一个低压窗口'
        if r['candidate_id']=='R007':status='现场解释为自动待机；当日换枪登记对应傍晚低压窗口'
        b=clock.bounds(ref['previous_record_date'],r['start'])
        if ref['working_comparison_basis']=='between_rule_supported_windows' and r['start']==ref.get('matched_start'):
            b=dict(on_min=ref['observed_on_min_hours'],on_max=ref['observed_on_max_hours'],missing_max=ref['unobserved_max_hours'],possible_max=ref['possible_on_max_hours'])
        candidate_check=next((x for x in ref.get('candidate_working_hour_checks',[]) if stop is not None and x['window_id']==stop.window_id),None)
        r.update(updated_assessment=status,window_id=stop.window_id if stop is not None else '',record_ids=record_ids,reference_record_id=ref['record_id'],reference_record_date=ref['date'],recorded_working_hours=ref['working_hours'],hours_before_candidate_min=b['on_min'],hours_before_candidate_max=b['on_max'],hours_before_candidate_unknown=b['missing_max'],hours_before_candidate_possible_max=b['possible_max'],candidate_working_hour_check=candidate_check,site_rule_window_supported=bool(stop.site_rule_window_supported) if stop is not None else False,record_window_ambiguous=bool(stop.record_window_ambiguous) if stop is not None else False,actual_window_confirmed=False,exact_replacement_time='')
        rows.append(r)
    # Missing-record hypothesis: compare a low-stop without same-day record to
    # the next record's life, without adding a fictitious registry row.
    for g in records:
        if g['serial_chain_matches'] or g['match_state']!='unique_site_rule':continue
        missing=audit[audit.site_rule_stop_eligible&audit.start.gt(g['previous_record_date'])&audit.start.lt(g['matched_start'])&audit.record_ids.eq('')]
        candidates=[]
        for w in missing.itertuples():
            m=clock.measure(w.end+pd.Timedelta(seconds=1),g['matched_start'])
            candidates.append(dict(window_id=w.window_id,start=w.start,end=w.end,observed_on_hours=m['on_hours'],possible_on_hours=m['on_hours']+m['missing_hours'],recorded_hours=g['working_hours'],unobserved_hours=m['missing_hours'],absolute_difference=abs(m['on_hours']-g['working_hours'])))
        if candidates:
            proposal=min(candidates,key=lambda x:x['absolute_difference']);g['missing_record_hypothesis']=proposal
            g['counter_hypothesis']='中间低压停喷后累计带电与下次记录时长接近，提示可能漏记或枪号录入问题；未补写换枪事件'
    return rows

def product_age(p,records,clock,audit=None):
    for col in ['record_cycle_id','gun_serial_from_record','gun_cycle_assignment']:p[col]=''
    for col in ['observed_gun_age_min_hours','possible_gun_age_max_hours']:p[col]=np.nan
    for ix,r in p.iterrows():
        day=r.start.normalize();same=next((g for g in records if g['date']==day),None)
        later=next((g for g in records if g['date']>day),None)
        previous=[g for g in records if g['date']<day]
        if audit is not None:
            missing=audit[audit.site_rule_stop_eligible&audit.record_ids.eq('')&audit.end.lt(r.start)]
            prev_date=previous[-1]['date'] if previous else records[0]['previous_record_date']
            if len(missing) and missing.end.max()>prev_date and not same:
                p.loc[ix,'gun_cycle_assignment']='未登记低压停喷后，枪号和周期起点待核实，不强填年龄';continue
        if same:
            p.loc[ix,'record_cycle_id']=same['record_id']
            if same['match_state']=='unique_site_rule':
                serial=same['old_serial'] if r.end<same['matched_start'] else same['new_serial'] if r.start>same['matched_end'] else ''
                p.loc[ix,'gun_serial_from_record']=serial;p.loc[ix,'gun_cycle_assignment']='按记录日及现场规则窗口推定；非工单精确时刻'
            else:p.loc[ix,'gun_cycle_assignment']='换枪当天，具体窗口未唯一确定，不强填枪号'
            continue
        if later and not later['serial_chain_matches']:
            p.loc[ix,'record_cycle_id']=later['record_id'];p.loc[ix,'gun_cycle_assignment']='相邻记录枪号不衔接，周期起点不完整，不强填枪号或年龄';continue
        if previous:
            prev=previous[-1];since=prev['date'];serial=prev['new_serial'];cid='after_'+prev['record_id']
            if prev['match_state']=='unique_site_rule':
                m=clock.measure(prev['matched_end']+pd.Timedelta(seconds=1),r.start);b=dict(on_min=m['on_hours'],possible_max=m['on_hours']+m['missing_hours'])
            else:b=clock.bounds(since,r.start)
        else:
            ref=records[0];since=ref['previous_record_date'];serial=ref['old_serial'];cid=ref['record_id'];b=clock.bounds(since,r.start)
        p.loc[ix,'record_cycle_id']=cid;p.loc[ix,'gun_serial_from_record']=serial;p.loc[ix,'gun_cycle_assignment']='按登记及规则窗口推定，带电时长仅作估算'
        p.loc[ix,'observed_gun_age_min_hours']=b['on_min'];p.loc[ix,'possible_gun_age_max_hours']=b['possible_max']
    return p

def reference_1016(root,out,cfg):
    file=root/'Voltage Sample/16_Oct_2026H14.csv'
    d=pd.read_csv(file,sep=';',encoding='utf-8-sig',skipinitialspace=True,usecols=lambda c:c.strip() in ['Date-Time','Time_s','Voltage','Station_1','Station_2']);d.columns=d.columns.str.strip()
    d['timestamp']=pd.to_datetime(d['Date-Time'],format=FMT);d['source_row']=np.arange(len(d))+2
    selection=d[d.Time_s.between(1162,2089)];start,end=selection.timestamp.iloc[0],selection.timestamp.iloc[-1]
    context=d[d.timestamp.between(start-pd.Timedelta(minutes=3),end+pd.Timedelta(minutes=3))].copy()
    products=[]
    for station in [1,2]:
        active=d[f'Station_{station}'].gt(50)
        for q in raw.contiguous_runs(d,active,2):
            if len(q)<15 or q.timestamp.max()<start or q.timestamp.min()>end:continue
            valid=not q[f'Station_{3-station}'].gt(50).any() and q.Voltage.notna().all()
            products.append(dict(sample_id=f'REF1016-{len(products)+1:02d}',start=q.timestamp.iloc[0],end=q.timestamp.iloc[-1],station=station,voltage_mean=q.Voltage.mean(),reference_voltage_fail=int(q.Voltage.mean()<51) if valid else None,label_valid=int(valid),source_row_start=int(q.source_row.iloc[0]),source_row_end=int(q.source_row.iloc[-1])))
    products=pd.DataFrame(products).sort_values('start')
    active=selection.Station_1.gt(50)|selection.Station_2.gt(50)
    info=dict(device='Booth1',file=file.name,selection_basis='Time_s 1162–2089; row-number interpretation differs only by seconds here',selection_start=start,selection_end=end,context_start=context.timestamp.min(),context_end=context.timestamp.max(),product_intervals=len(products),product_voltage_failures=int(products.reference_voltage_fail.eq(1).sum()),product_voltage_min=float(products.voltage_mean.min()),product_voltage_max=float(products.voltage_mean.max()),raw_low_points=int(selection.Voltage.lt(51).sum()),raw_low_points_with_station_active=int((selection.Voltage.lt(51)&active).sum()),last_station_active_at=selection.loc[active,'timestamp'].max(),site_hypothesis='郭工答复：初期不稳有可能；不是已确认原因',conclusion='本指定片段未见产品平均电压失败，低压点发生在无转台加工阶段；停喷原因仍未记录，不直接认定待机或初期不稳',source_sha256=hashlib.sha256(file.read_bytes()).hexdigest())
    raw.write_csv(context.drop(columns='timestamp'),out/'参考样本/16_Oct_2026H14_指定片段_前后各3分钟.csv',raw=True)
    raw.write_csv(products,out/'参考样本/16_Oct_2026H14_产品电压核对.csv');dump(info,out/'参考样本/16_Oct_2026H14_核对说明.json')
    return info

def run(root,base,book,out,cfg):
    root,base,out=root.resolve(),base.resolve(),out.resolve()
    if out==root or out==base or out.is_relative_to(base) or base.is_relative_to(out):raise ValueError('Keep source data and new analysis separate')
    out.mkdir(parents=True,exist_ok=True)
    for name in ['来源文件清单.csv','每日数据检查.csv','日内采样缺口.csv','分段参数敏感性.csv','规则来源核对.json','设备带电状态区间.csv','主数据电压分钟走势.csv']:shutil.copy2(base/name,out/name)
    sensitivity=load(out/'分段参数敏感性.csv');sensitivity['analysis_scope']=cfg['analysis_start']+' through '+cfg['analysis_end_exclusive']
    sensitivity['scope_note']='完整周期分段；换向间隙敏感性见换向参数核对.json';raw.write_csv(sensitivity,out/'分段参数敏感性.csv')
    shutil.copytree(base/'参考样本',out/'参考样本',dirs_exist_ok=True)
    p=revise_products(load(base/'产品级标签.csv',['start','end','label_available_at','power_episode_start']),cfg);p['analysis_asset']='Booth2'
    m=load(base/'来源文件清单.csv',['time_start','time_end']).fillna({'zip_member':'','identical_bytes_to':''})
    if (base/'新增数据核对.json').exists():shutil.copy2(base/'新增数据核对.json',out/'新增数据核对.json')
    clock=make_clock(root,m,out,cfg)
    audit=annotate_stops(p,load(base/'停复机全量审查.csv',['start','end','resume_at','evidence_available_at']),clock,cfg)
    records=gun_records(book,pd.Timestamp(cfg['analysis_start']),pd.Timestamp(cfg['analysis_end_exclusive']),cfg['record_asset'])
    records,audit=annotate_records(records,audit,clock,p)
    records,audit=site_alignment.align(records,audit,p,clock)
    candidates=old_candidates(load(base/'换枪候选索引.csv',['start','end','resume_at','evidence_available_at']),records,clock,audit)
    triggers=shutdown_followup(p,load(base/'设备带电状态区间.csv',['start','end']),audit)
    p=site_alignment.assign_cycles(p,records,clock,audit)
    p['replacement_candidate_ids']='';p['record_context_ids']='';p['rule_supported_record_ids']='';p['ambiguous_record_ids']=''
    ids=set(p.loc[p.failure.eq(1)|p.label_valid.eq(0)|p.sampling_released.eq(1)|p.site_override.eq(1),'product_id']);record_events=[]
    for r in candidates:
        members=set(r['product_ids'].split(';'));ids|=members;hit=p.product_id.isin(members)
        p.loc[hit,'replacement_candidate_ids']=p.loc[hit,'replacement_candidate_ids'].map(lambda x:';'.join(filter(None,[x,r['candidate_id']])))
    for g in records:
        windows=g['supported_window_ids'].split(';') if g['supported_window_ids'] else []
        for wid in windows:
            w=audit[audit.window_id.eq(wid)].iloc[0]
            pre=p[p.end.lt(w.start)&p.end.ge(w.start-pd.Timedelta(hours=1))].tail(3)
            post=p[p.start.gt(w.end)&p.start.le(w.end+pd.Timedelta(hours=1))].head(3)
            members=set([*pre.product_id,*post.product_id,*str(w.low_product_ids).split(';')]);members.discard('');ids|=members;hit=p.product_id.isin(members)
            p.loc[hit,'record_context_ids']=p.loc[hit,'record_context_ids'].map(lambda x:';'.join(dict.fromkeys(filter(None,[x,g['record_id']]))))
            field='rule_supported_record_ids' if g['match_state'] in ['unique_site_rule','site_confirmed'] else 'ambiguous_record_ids' if g['match_state']=='multiple_low_stop_windows' else None
            if field:p.loc[hit,field]=p.loc[hit,field].map(lambda x:';'.join(filter(None,[x,g['record_id']])))
            record_events.append(dict(event_id=g['record_id']+'_'+wid,record_id=g['record_id'],window_id=wid,event_kind='record_window',start=w.start,end=w.end,product_ids=';'.join(sorted(members)),origin_label='现场规则支持的换枪窗口' if g['match_state'] in ['unique_site_rule','site_confirmed'] else '同日多窗口待分辨' if g['match_state']=='multiple_low_stop_windows' else '换枪记录日信号示例，非确认时刻'))
    unregistered=[]
    for w in audit[audit.site_rule_stop_eligible&audit.record_ids.eq('')].itertuples():
        pre=p[p.end.lt(w.start)&p.end.ge(w.start-pd.Timedelta(hours=1))].tail(3)
        post=p[p.start.gt(w.end)&p.start.le(w.end+pd.Timedelta(hours=1))].head(3)
        members=set([*pre.product_id,*post.product_id,*str(w.low_product_ids).split(';')]);members.discard('');ids|=members
        ev=dict(event_id='U_'+w.window_id,window_id=w.window_id,event_kind='unregistered_low_stop',start=w.start,end=w.end,product_ids=';'.join(sorted(members)),origin_label='连续低压后停喷，但缺少同日换枪登记')
        unregistered.append(dict(ev,low_failed_products=w.low_failed_products));record_events.append(ev)
        hit=p.product_id.isin(str(w.low_product_ids).split(';'))
        p.loc[hit,'origin_label']='低压失败；随后停喷但缺少同日换枪登记'
        p.loc[hit,'origin_evidence']='产品均值低于51 V；随后停喷和电压恢复只构成核查线索，没有同日登记，不确认换枪或寿命耗尽。'
    # Attach action evidence without turning all low-voltage failures into EOL.
    for ix,r in p[p.voltage_fail.eq(1)].iterrows():
        if r.rule_supported_record_ids:p.loc[ix,'origin_label']='低压失败；记录日低压停喷后换枪（现场规则支持）'
        elif r.ambiguous_record_ids:p.loc[ix,'origin_label']='低压失败；当日换枪窗口有歧义'
    for g in records:
        if g['action_type'] in ['preventive','replacement_after_reported_damage']:continue
        for wid in filter(None,g['supported_window_ids'].split(';')):
            w=audit[audit.window_id.eq(wid)].iloc[0];hit=p.product_id.isin(str(w.low_product_ids).split(';'))&p.voltage_fail.eq(1)
            p.loc[hit,['origin_label','origin_evidence','cause_basis']]=['连续低压后更换（登记与信号对应）','产品低压序列后停喷，与该日更换登记或现场确认对应；实际拆装分钟未知。','register_and_low_sequence_eol_inference']
    p=site_alignment.label_causes(p)
    p['attention']=p.product_id.isin(ids).astype(int)
    raw.write_csv(p,out/'产品级标签.csv');raw.write_csv(audit,out/'停喷观察全量.csv')
    raw.write_csv(pd.DataFrame(records).drop(columns=['missing_record_hypothesis'],errors='ignore'),out/'Booth2换枪记录与窗口核对.csv')
    raw.write_csv(pd.DataFrame(candidates),out/'历史8处候选核对.csv')
    dump(records,out/'Booth2换枪记录与窗口核对.json');dump(candidates,out/'历史8处候选核对.json');dump(triggers,out/'连续失败与停喷核对.json')
    oldevents=load(base/'关注事件索引.csv',['start','end','event_time','resume_at']);events=[]
    for ev in oldevents[oldevents.event_kind.eq('product_failure')].to_dict('records'):
        q=p[p.product_id.isin(str(ev['product_ids']).split(';'))&p.failure.eq(1)]
        if len(q):ev.update(start=q.start.min(),end=q.end.max(),product_ids=';'.join(q.product_id),failed_product_count=len(q),origin_label='Booth2产品阈值失败');events.append(ev)
    for ev in oldevents[oldevents.event_kind.eq('replacement_candidate')].to_dict('records'):
        ev['origin_label']=next(c['updated_assessment'] for c in candidates if c['candidate_id']==ev['event_id']);events.append(ev)
    for r in p[p.label_valid.eq(0)].itertuples():
        events.append(dict(event_id='Q_'+r.product_id,event_kind='product_review',start=r.start,end=r.end,product_ids=r.product_id,origin_label='加工完整性待核实'))
    events.extend(record_events);events=pd.DataFrame(events);raw.write_csv(events,out/'关注事件索引.csv')
    p['attention_event_ids']=''
    for ev in events.itertuples():
        hit=p.product_id.isin(str(ev.product_ids).split(';'))
        p.loc[hit,'attention_event_ids']=p.loc[hit,'attention_event_ids'].map(lambda x:';'.join(filter(None,[x,ev.event_id])))
    raw.write_csv(p,out/'产品级标签.csv');dump(unregistered,out/'未登记低压停喷线索.json')
    excerpts=raw.export_excerpts(root,m,p,events,cfg,out)
    ref=load(out/'参考样本/末期产品核对.csv',['start','end']);ref['derived_voltage_rule_trigger']=0;run_count=0
    for ix,r in ref.iterrows():
        run_count=run_count+1 if r.label_valid==1 and r.reference_voltage_fail==1 else 0
        if run_count==3:ref.loc[ix,'derived_voltage_rule_trigger']=1
    ref=ref.drop(columns=['derived_voltage_two_consecutive_trigger'],errors='ignore');raw.write_csv(ref,out/'参考样本/末期产品核对.csv')
    info=json.loads((out/'参考样本/参考信息.json').read_text('utf-8'));info.pop('reference_two_consecutive_rule_triggers',None)
    info.update(device='Booth1_reference_not_target',reference_original_shutdown_required_consecutive_failures=3,reference_consecutive_rule_triggers=int(ref.derived_voltage_rule_trigger.sum()));dump(info,out/'参考样本/参考信息.json')
    early=None
    summary=dict(version=cfg['version'],main_asset='Booth2',reference_asset='Booth1',products=len(p),normal_products=int(p.failure.eq(0).sum()),failed_products=int(p.failure.eq(1).sum()),unknown_products=int(p.failure.isna().sum()),hmi_threshold_failures=int(p.failure_hmi.eq(1).sum()),reason_counts={k:int(p[k].sum()) for k in ['voltage_fail','feedrate_fail','hopper_pressure_fail']},sampling_released=int(p.sampling_released.sum()),released_failure_count=int(p.loc[p.sampling_released.eq(1),'failure'].sum()),site_overrides=int(p.site_override.sum()),attention_products=int(p.attention.sum()),audited_stop_windows=len(audit),recorded_changes=len(records),unique_rule_matches=sum(g['match_state'] in ['unique_site_rule','site_confirmed'] for g in records),ambiguous_record_matches=sum(g['match_state']=='multiple_low_stop_windows' for g in records),record_only_matches=sum(g['match_state']=='record_only_no_low_stop' for g in records),serial_chain_issues=sum(not g['serial_chain_matches'] for g in records),counter_disagreements=sum(g['working_hours_conflict'] for g in records),rule_supported_stop_windows=int(audit.site_rule_window_supported.sum()),standby_compatible_stops=int(audit.standby_compatible.sum()),exact_time_confirmed_records=0,derived_shutdowns=len(triggers),shutdown_followup_counts=pd.Series([t['stop_relation'] for t in triggers]).value_counts().to_dict(),reference_trigger_products=3,reference_trigger_time=ref.loc[ref.derived_voltage_rule_trigger.eq(1),'end'].iloc[0],model_training_performed=False,**excerpts)
    main=m[m.data_stream.eq('main')&m.identical_bytes_to.eq('')&m.rows.gt(0)].sort_values('time_start')
    # An hour/date not supplied is not an observed stopped machine.
    gaps=[];last=None
    for r in main.itertuples():
        if last is not None and (r.time_start-last).total_seconds()>3600:gaps.append(dict(after=last,before=r.time_start,hours=(r.time_start-last).total_seconds()/3600))
        last=max(last,r.time_end) if last is not None else r.time_end
    expected=p.end.sub(p.start).dt.total_seconds()+1
    summary.update(analysis_start=cfg['analysis_start'],analysis_end_exclusive=cfg['analysis_end_exclusive'],main_source_files=len(main),unprovided_source_gaps=gaps,unregistered_low_stop_windows=len(unregistered),coarse_date_counter_disagreements=sum(g['date_bound_hours_conflict'] for g in records),products_with_missing_points=int(p.samples.lt(expected).sum()),new_products_with_missing_points=int((p.samples.lt(expected)&p.start.ge('2026-10-27')).sum()),new_data=json.loads((base/'新增数据核对.json').read_text('utf-8')) if (base/'新增数据核对.json').exists() else None)
    dump(summary,out/'汇总.json');dump(cfg,out/'使用的参数.json')
    sources=dict(main_asset='Booth2',reference_asset='Booth1',gun_record_file=str(book),gun_record_sha256=hashlib.sha256(book.read_bytes()).hexdigest(),selected_asset=cfg['record_asset'],record_date_range=[cfg['analysis_start'],cfg['analysis_end_exclusive']],site_reply_source=cfg['site_process_confirmation']['source'],site_reply_sha256=cfg['site_process_confirmation']['sha256'],chat_sources=cfg['site_chat_confirmation'].get('source_sha256',{}))
    dump(sources,out/'来源与现场确认.json');print(json.dumps(clean(summary),ensure_ascii=False,indent=2),flush=True);return summary

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);a.add_argument('--base',type=Path,required=True);a.add_argument('--gun-records',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--config',type=Path,default=Path(__file__).with_name('config.json'));v=a.parse_args();run(v.root,v.base,v.gun_records,v.output,json.loads(v.config.read_text('utf-8')))
