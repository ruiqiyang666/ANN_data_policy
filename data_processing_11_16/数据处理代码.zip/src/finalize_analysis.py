from pathlib import Path
import json,argparse
import pandas as pd
import data_io as raw
from common import load,dump

def finish(root,base,out,cfg):
 p=load(out/'产品级标签.csv',['start','end','label_available_at']);e=load(out/'关注事件索引.csv',['start','end'])
 for ix,r in p[p.old_sample_ids.fillna('').str.contains('P000610|P000732')].iterrows():
  id='C_'+r.product_id
  if not e.event_id.eq(id).any():e=pd.concat([e,pd.DataFrame([dict(event_id=id,event_kind='product_review',start=r.start,end=r.end,product_ids=r.product_id,origin_label='完整加工周期示例')])],ignore_index=True)
  p.loc[ix,'attention']=1;p.loc[ix,'attention_event_ids']=';'.join(dict.fromkeys([*str(r.attention_event_ids if pd.notna(r.attention_event_ids) else '').split(';'),id])).strip(';')
 raw.write_csv(p,out/'产品级标签.csv');raw.write_csv(e,out/'关注事件索引.csv')
 m=load(out/'来源文件清单.csv',['time_start','time_end']).fillna({'zip_member':'','identical_bytes_to':''})
 ex=raw.export_excerpts(root,m,p,e,cfg,out)
 s=json.loads((out/'汇总.json').read_text('utf-8'));s.update(ex);s['attention_products']=int(p.attention.sum());s['excluded_special_intervals']=int(p.quality_flags.fillna('').str.contains('其他配方').sum());s['other_unresolved_intervals']=int(p.label_valid.eq(0).sum())-s['excluded_special_intervals']
 new=p[p.start.ge('2026-11-02')];s['new_data'].update(new_products=len(new),new_hmi_failures=int(new.failure_hmi.eq(1).sum()),new_unresolved=int(new.label_valid.eq(0).sum()),new_failure_reasons={k:int(new[k].sum()) for k in ['voltage_fail','feedrate_fail','hopper_pressure_fail']},old_product_boundaries_preserved=False,old_fragment_crosswalk_available=True)
 dump(s,out/'汇总.json');dump(s['new_data'],out/'新增数据核对.json')
 info=json.loads((out/'参考样本/参考信息.json').read_text('utf-8'));ref=load(out/'参考样本/末期产品核对.csv',['start','end']);info.update(products=len(ref),valid_products=int(ref.label_valid.sum()),voltage_failures=int(ref.reference_voltage_fail.eq(1).sum()),segmentation='Complete cycle; brief same-station reversal dip retained; no other Booth1 sensors used');dump(info,out/'参考样本/参考信息.json')
 for name in ['16_Oct_2026H14_产品电压核对.csv','16_Oct_2026H14_核对说明.json','16_Oct_2026H14_指定片段_前后各3分钟.csv','自然失效比较模板.csv']:
  target=out/'参考样本'/name
  if target.exists():target.unlink()
 print('Updated examples and full-cycle statistics',flush=True)

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);a.add_argument('--base',type=Path,required=True);a.add_argument('--output',type=Path,required=True);a.add_argument('--config',type=Path,required=True);v=a.parse_args();finish(v.root,v.base,v.output,json.loads(v.config.read_text('utf-8')))
