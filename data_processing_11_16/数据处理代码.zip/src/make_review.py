"""Updated static scientific figures; all are embedded in the review HTML."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as md
from process_data import load,FMT

plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':10,'axes.spines.top':False,
    'axes.spines.right':False,'axes.unicode_minus':False})


def plots(out):
    charts=out/'图表';charts.mkdir(exist_ok=True)
    p=load(out/'产品级标签.csv',['start','end'])
    e=load(out/'关注事件索引.csv',['start','end'])
    c=load(out/'历史8处候选核对.csv',['start','end']); summary=json.loads((out/'汇总.json').read_text('utf-8'))
    ref=load(out/'参考样本/末期产品核对.csv',['start','end'])
    raw=[]
    for file in (out/'关注片段_28参数').rglob('*.csv'):
        d=pd.read_csv(file,sep=';');d['timestamp']=pd.to_datetime(d['Date-Time'],format=FMT);raw.append(d)
    data=pd.concat(raw,ignore_index=True).sort_values('timestamp').drop_duplicates('timestamp')
    fig,ax=plt.subplots(figsize=(13,4),layout='constrained')
    q=ref[ref.start.between('2026-10-27 13:35','2026-10-27 14:20')]
    ax.plot(q.end,q.voltage_mean,lw=.8,c='#93a4b7')
    good=q.label_valid.eq(1)
    ax.scatter(q.loc[good,'end'],q.loc[good,'voltage_mean'],s=25,c=np.where(q.loc[good,'reference_voltage_fail'].eq(1),'#bc4039','#31638f'))
    if (~good).any():ax.scatter(q.loc[~good,'end'],q.loc[~good,'voltage_mean'],s=25,c='#909090',marker='x',label='区间完整性待核实')
    ax.axhline(51,c='#bc4039',ls='--',label='产品平均电压 51 V')
    ax.axvline(pd.to_datetime(summary['reference_trigger_time'],format=FMT),c='#b58535',ls=':',label='连续三件低压：参考设备原设置')
    ax.axvline(pd.Timestamp('2026-10-27 14:12:35'),c='#555',ls=':',label='之后进入低电压／停止段')
    ax.set(title='Booth1寿命末期参考：自身Station划分产品，按原三件设置核对',ylabel='候选产品平均电压 (V)')
    ax.xaxis.set_major_formatter(md.DateFormatter('%H:%M'));ax.grid(axis='y',alpha=.15);ax.legend(frameon=False,fontsize=8)
    fig.savefig(charts/'01_reference_products.png',dpi=140);plt.close(fig)
    fig,ax=plt.subplots(figsize=(13,4),layout='constrained')
    valid=p.label_valid.eq(1);low=valid&p.voltage_fail.eq(1)
    ax.scatter(p.loc[valid,'end'],p.loc[valid,'voltage_mean'],s=3,c='#7997b3',alpha=.65,label='可判定产品')
    ax.scatter(p.loc[low,'end'],p.loc[low,'voltage_mean'],s=20,c='#bc4039',label=f'{int(low.sum())}件产品平均电压低于51 V')
    ax.axhline(51,c='#bc4039',ls='--',lw=1);ax.set(ylim=(44,59),ylabel='产品平均电压 (V)',title='Booth2主数据：2026-09-12 至 2026-11-14')
    ax.xaxis.set_major_formatter(md.DateFormatter('%m-%d'));ax.legend(frameon=False,fontsize=8);ax.grid(axis='y',alpha=.15)
    fig.savefig(charts/'02_main_voltage.png',dpi=140);plt.close(fig)
    def detail(id,title,start,end,product_ids=None,pressure=False):
        if product_ids:
            prod=p[p.product_id.isin(product_ids.split(';'))]
            lo=min(prod.start.min(),start)-pd.Timedelta(minutes=3);hi=max(prod.end.max(),end)+pd.Timedelta(minutes=3)
        else:lo=start-pd.Timedelta(minutes=15);hi=end+pd.Timedelta(minutes=4);prod=p[p.start.between(lo,hi)]
        d=data[data.timestamp.between(lo,hi)].copy()
        breaks=d.timestamp.diff().dt.total_seconds().gt(2)
        for name in ['Current','Feedrate_1','Feedrate_2','Press._Hopper_1','Press._Hopper_2','Station_1','Station_2']:
            d.loc[breaks,name]=np.nan
        fig,axes=plt.subplots(4,1,figsize=(13,8),layout='constrained',sharex=True)
        axes[0].scatter(prod.end,prod.voltage_mean,s=22,c=np.where(prod.voltage_fail.eq(1),'#bc4039','#31638f'))
        axes[0].axhline(51,c='#bc4039',ls='--',lw=1);axes[0].set(ylabel='产品电压均值 V',title=title,ylim=(44,59))
        axes[1].plot(d.timestamp,d.Current,c='#526e89',lw=.8);axes[1].set(ylabel='电流 A')
        for h,color in [(1,'#367d6b'),(2,'#9b7946')]:axes[2].plot(d.timestamp,d[f'Feedrate_{h}'],c=color,lw=.8,label=f'料斗{h}')
        axes[2].axhline(9.1,c='#999',ls=':',lw=.7);axes[2].axhline(11.1,c='#999',ls=':',lw=.7);axes[2].set(ylabel='送料 g/min');axes[2].legend(frameon=False,fontsize=8,ncol=2)
        for h in [1,2]:axes[3].plot(d.timestamp,d[f'Press._Hopper_{h}' if pressure else f'Station_{h}'],lw=.8,label=f'料斗{h}' if pressure else f'Station {h}')
        if pressure:axes[3].axhline(250,c='#bc4039',ls='--',lw=1)
        axes[3].set(ylabel='压力 mbar' if pressure else '转台转速 rpm');axes[3].legend(frameon=False,fontsize=8,ncol=2)
        for ax in axes:ax.axvspan(start,end,color='#c8a058',alpha=.15);ax.grid(axis='y',alpha=.12)
        axes[-1].xaxis.set_major_formatter(md.DateFormatter('%m-%d\n%H:%M'));axes[-1].set_xlim(lo,hi)
        fig.savefig(charts/f'{id}.png',dpi=125);plt.close(fig)
    for r in e[e.event_kind.eq('product_failure')].itertuples():
        detail(r.event_id,'产品均值与加工记录：'+r.event_id,r.start,r.end,r.product_ids,pressure=p[p.product_id.isin(str(r.product_ids).split(';'))].hopper_pressure_fail.eq(1).any())

    for r in c.to_dict('records'):
        title=r['candidate_id']+'  '+r['updated_assessment']+'\n阴影是历史停喷观察窗口，更换证据与实际动作另见登记表'
        detail(r['candidate_id'],title,r['start'],r['end'],r['product_ids'])
    for r in e[e.event_kind.isin(['record_window','unregistered_low_stop'])].to_dict('records'):
        detail(r['event_id'],r['event_id']+'  '+r['origin_label']+'\nBooth2登记日的停喷观察区间，未提供精确操作时刻',r['start'],r['end'],r['product_ids'])
    for r in p[p.old_sample_ids.fillna('').str.contains('P000610|P000732')].itertuples():
        q=data[data.timestamp.between(r.start-pd.Timedelta(seconds=8),r.end+pd.Timedelta(seconds=8))]
        fig,axs=plt.subplots(2,1,figsize=(12,5),sharex=True,layout='constrained')
        axs[0].plot(q.timestamp,q.Voltage,lw=1,label='原始电压');axs[0].axhline(r.voltage_mean,color='#31638f',label=f'整件均值 {r.voltage_mean:.3f} V');axs[0].axhline(51,color='#bc4039',ls='--',label='失败阈值51 V');axs[0].legend(fontsize=8);axs[0].set(ylabel='电压 V',title=f'{r.product_id} · 完整周期 {r.duration_seconds:.0f}秒')
        axs[1].plot(q.timestamp,q[f'Station_{int(r.station)}'],label=f'Station {r.station}');axs[1].axhline(50,color='#999',ls=':');axs[1].set(ylabel='转台转速 rpm');axs[1].legend(fontsize=8)
        for ax in axs:ax.axvspan(r.start,r.end,color='#9cb8c9',alpha=.12);ax.grid(axis='y',alpha=.2)
        axs[1].xaxis.set_major_formatter(md.DateFormatter('%H:%M:%S'))
        fig.savefig(charts/f'cycle_{r.product_id}.png',dpi=130);plt.close(fig)
    print('Generated figures:',len(list(charts.glob('*.png'))))


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();plots(a.output)
