"""Read-only raw sensor I/O. Original fields are preserved in excerpt exports."""

from pathlib import Path
import io,zipfile,json
import numpy as np
import pandas as pd

PHYSICAL = ['Argon','Nitrogen','AirJet','Silvent','Current','Power','Voltage',
 'Cooling_water_flow','Conductivity','Cooling_water_inlet_temp.','Cooling_water_outlet_temp.',
 'Feedrate_1','Disk_1','Carrier_gas_1','Feed_Factor_1','Press._Hopper_1','Stirrer_1','Weight_Hopper_1',
 'Feedrate_2','Disk_2','Carrier_gas_2','Feed_Factor_2','Press._Hopper_2','Stirrer_2','Weight_Hopper_2',
 'Station_1','Station_2','O2_Sensor']

ORIGINAL = ['Date-Time','Time_s',*PHYSICAL]

TIME_FORMAT = '%d %m %Y %H:%M:%S'

def write_csv(frame, path, raw=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path,index=False,encoding='utf-8-sig',sep=';' if raw else ',',
                 float_format='%.12g',date_format=TIME_FORMAT)

def dump(value, path):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')

def payload(root, row):
    if row['zip_member']:
        with zipfile.ZipFile(root/row['container']) as archive:
            return archive.read(row['zip_member'])
    return (root/row['container']).read_bytes()

def parse_csv(data, voltage_only=False, strings=False):
    options=dict(sep=';',encoding='utf-8-sig',skipinitialspace=True)
    if voltage_only: options['usecols']=lambda x:x.strip() in ['Date-Time','Voltage']
    if strings: options.update(dtype=str,keep_default_na=False)
    d=pd.read_csv(io.BytesIO(data),**options)
    d.columns=d.columns.str.strip()
    required=['Date-Time','Voltage'] if voltage_only else ORIGINAL
    missing=set(required)-set(d.columns)
    if missing: raise ValueError('Missing required fields: '+repr(sorted(missing)))
    d=d[required].copy()
    if strings:
        for column in d: d[column]=d[column].str.strip()
    else:
        for column in d:
            if column!='Date-Time':
                d[column]=pd.to_numeric(d[column],errors='coerce').replace([np.inf,-np.inf],np.nan)
    d['timestamp']=pd.to_datetime(d['Date-Time'],format=TIME_FORMAT,errors='coerce')
    return d

def contiguous_runs(d,mask,maxgap=2):
    mask=mask.fillna(False)
    starts=mask & (~mask.shift(fill_value=False)|d.timestamp.diff().dt.total_seconds().gt(maxgap))
    group=starts.cumsum()
    for _,q in d[mask].groupby(group[mask],sort=False):yield q


def load_day(root,m,day):
    frames=[]
    for r in m[(m.data_stream=='main')&m.identical_bytes_to.eq('')&m.time_start.dt.date.eq(day)&m.rows.gt(0)].to_dict('records'):
        d=parse_csv(payload(root,r));d['source_id']=r['source_id'];d['source_row']=np.arange(len(d))+2;frames.append(d)
    if not frames:return pd.DataFrame()
    d=pd.concat(frames,ignore_index=True).sort_values(['timestamp','source_id','source_row'],kind='stable')
    exact=d.duplicated(['timestamp',*PHYSICAL]);d=d[~exact].copy()
    d['timestamp_conflict']=d.timestamp.duplicated(keep=False)
    conflicts=d.loc[d.timestamp_conflict,['timestamp','source_id','source_row']].copy()
    d=d.drop_duplicates('timestamp').reset_index(drop=True)
    return d,dict(identical_rows_removed=int(exact.sum()),conflicting_rows=len(conflicts))

def export_excerpts(root,m,p,e,cfg,out):
    windows=[]
    for r in e.to_dict('records'):
        if r['event_kind'] in ['product_failure','product_review']:
            windows.append(dict(start=r['start']-pd.Timedelta(minutes=cfg['excerpt_before_minutes']),end=r['end']+pd.Timedelta(minutes=cfg['excerpt_after_minutes']),event_id=r['event_id']))
        else:
            related=p[p.product_id.isin(str(r['product_ids']).split(';'))]
            pre=related[related.end.lt(r['start'])];post=related[related.start.gt(r['end'])]
            lo=min(r['start']-pd.Timedelta(minutes=5),pre.start.min()) if len(pre) else r['start']-pd.Timedelta(minutes=5)
            hi=max(r['end']+pd.Timedelta(minutes=5),post.end.max()) if len(post) else r['end']+pd.Timedelta(minutes=5)
            windows.append(dict(start=lo,end=r['start']+pd.Timedelta(minutes=2),event_id=r['event_id']))
            windows.append(dict(start=r['end']-pd.Timedelta(minutes=2),end=hi,event_id=r['event_id']))
    attention=pd.DataFrame(windows)
    total=0;files=0;recheck=[]
    for r in m[(m.data_stream=='main')&m.identical_bytes_to.eq('')&m.rows.gt(0)].to_dict('records'):
        wins=attention[(attention.start<=r['time_end'])&(attention.end>=r['time_start'])]
        if wins.empty:continue
        d=parse_csv(payload(root,r),strings=True);d['source_row']=np.arange(len(d))+2
        keep=np.zeros(len(d),bool)
        for w in wins.to_dict('records'):keep|=d.timestamp.between(w['start'],w['end']).to_numpy()
        d=d[keep & d.timestamp.ge(cfg['analysis_start']) & d.timestamp.lt(cfg['analysis_end_exclusive'])].copy()
        if d.empty:continue
        d['product_id']='';d['failure']='';d['failure_type']='not_applicable';d['label_valid']=0
        d['voltage_fail']='';d['feedrate_fail']='';d['hopper_pressure_fail']=''
        d['origin_label']='非加工/启停或产品间隙';d['origin_evidence']='不在已识别完整产品区间，failure留空'
        d['attention_event_ids']='';d['review_event_labels']=''
        d['source_id']=r['source_id'];d['cause_confirmed']=0
        d['origin_label_uses_future_context']=1
        d['voltage_mean_product']='';d['feedrate_mean_product']='';d['pressure_mean_product']=''
        d['label_available_at']='';d['label_scope']='not_applicable';d['quality_flags']=''
        for name in ['failure','voltage_fail','feedrate_fail','hopper_pressure_fail',
                     'voltage_mean_product','feedrate_mean_product','pressure_mean_product']:
            d[name]=d[name].astype(object)
        candidates=p[p.start.le(d.timestamp.max())&p.end.ge(d.timestamp.min())]
        for q in candidates.to_dict('records'):
            hit=d.timestamp.between(q['start'],q['end'])
            if not hit.any():continue
            values={k:q[k] for k in ['product_id','failure','failure_type','label_valid','voltage_fail','feedrate_fail','hopper_pressure_fail','origin_label','origin_evidence','quality_flags']}
            values.update(voltage_mean_product=q['voltage_mean'],feedrate_mean_product=q['feedrate_mean'],pressure_mean_product=q['pressure_mean'],label_available_at=q['label_available_at'].strftime(TIME_FORMAT) if pd.notna(q['label_available_at']) else '',label_scope='retrospective_product_label')
            for key,value in values.items():d.loc[hit,key]='' if pd.isna(value) else value
        for w in wins.to_dict('records'):
            hit=d.timestamp.between(w['start'],w['end'])
            d.loc[hit,'attention_event_ids']=d.loc[hit,'attention_event_ids'].map(lambda s:';'.join(sorted(set(filter(None,[*s.split(';'),w['event_id']])))))
        for er in e[e.event_kind.eq('replacement_candidate')].to_dict('records'):
            hit=d.timestamp.between(er['start']-pd.Timedelta(minutes=5),er['end']+pd.Timedelta(minutes=5))
            d.loc[hit,'review_event_labels']=d.loc[hit,'review_event_labels'].map(lambda s:';'.join(filter(None,[s,er['origin_label']])))
        d=d.drop(columns='timestamp')
        container=Path(r['container'])
        group=container.stem if r['zip_member'] else container.parts[0]
        filename=Path(r['zip_member']).name if r['zip_member'] else container.name
        dest=out/'关注片段_28参数'/group/filename
        write_csv(d,dest,raw=True);total+=len(d);files+=1
        # Round-trip original fields are compared, not merely row counts.
        again=parse_csv(dest.read_bytes(),strings=True)
        assert again[ORIGINAL].equals(d[ORIGINAL].reset_index(drop=True)),f'Raw values changed: {dest}'
        recheck.append(dict(relative_file=dest.relative_to(out).as_posix(),rows=len(d),source_id=r['source_id'],all_original_30_fields_preserved=True))
    write_csv(pd.DataFrame(recheck),out/'导出文件核对.csv')
    return dict(excerpt_files=files,excerpt_rows=total)


def failure_bits(voltage,feed,pressure,cfg):
    values=np.asarray([voltage,feed,pressure],dtype=float)
    if not np.isfinite(values).all():return None,None,None
    v,f,p=np.round(values,10)
    return int(v<cfg['voltage_failure_below_v']),int(f<cfg['feedrate_failure_below'] or f>cfg['feedrate_failure_above']),int(p<cfg['pressure_failure_below'] or p>cfg['pressure_failure_above'])


def extract_products(d,cfg,station_threshold=None,minimum=None):
    rows=[];threshold=cfg['station_threshold_rpm'] if station_threshold is None else station_threshold
    minimum=cfg['minimum_station_samples'] if minimum is None else minimum
    gap=d.timestamp.diff().dt.total_seconds(); maxgap=cfg['maximum_sampling_gap_seconds']
    for station in [1,2]:
        active=d[f'Station_{station}'].gt(threshold)
        for q in contiguous_runs(d,active,maxgap):
            if len(q)<minimum:continue
            left,right=int(q.index[0]),int(q.index[-1])
            start,end=q.timestamp.iloc[0],q.timestamp.iloc[-1]
            f1=q.Feedrate_1.gt(0);f2=q.Feedrate_2.gt(0)
            n1,n2=int(f1.sum()),int(f2.sum());hopper=1 if n1>n2 else 2 if n2>n1 else None
            record=dict(station=station,start=start,end=end,samples=len(q),
                coverage=len(q)/((end-start).total_seconds()+1),hopper=hopper,
                dual_feed_samples=int((f1&f2).sum()),other_station_running_samples=int(q[f'Station_{3-station}'].gt(threshold).sum()),
                left_boundary_observed=left>0 and gap.iloc[left]<=maxgap and not active.iloc[left-1],
                right_boundary_observed=right<len(d)-1 and gap.iloc[right+1]<=maxgap and not active.iloc[right+1],
                label_available_at=d.timestamp.iloc[right+1] if right<len(d)-1 and not active.iloc[right+1] and gap.iloc[right+1]<=maxgap else pd.NaT,
                conflict_samples=int(q.timestamp_conflict.sum()),
                source_start=q.source_id.iloc[0],source_row_start=int(q.source_row.iloc[0]),
                source_end=q.source_id.iloc[-1],source_row_end=int(q.source_row.iloc[-1]),
                voltage_mean=np.nan,feedrate_mean=np.nan,pressure_mean=np.nan,spray_samples=0,
                current_median=np.nan,argon_median=np.nan,nitrogen_median=np.nan,
                powered_fraction=np.nan,zero_feed_samples=np.nan,label_missing_values=0)
            if hopper:
                selected_feed=q[f'Feedrate_{hopper}']; z=q[selected_feed.gt(0)]
                record.update(spray_samples=len(z),voltage_mean=z.Voltage.mean(),
                    feedrate_mean=z[f'Feedrate_{hopper}'].mean(),pressure_mean=z[f'Press._Hopper_{hopper}'].mean(),
                    voltage_std=z.Voltage.std(),voltage_min=z.Voltage.min(),voltage_max=z.Voltage.max(),
                    current_median=z.Current.median(),argon_median=z.Argon.median(),nitrogen_median=z.Nitrogen.median(),
                    powered_fraction=((z.Current>cfg['powered_current_above_a'])&(z.Power>cfg['powered_power_above_kw'])).mean(),
                    zero_feed_samples=int(selected_feed.eq(0).sum()),
                    label_missing_values=int(q[[f'Feedrate_{hopper}']].isna().sum().sum()+z[['Voltage',f'Press._Hopper_{hopper}']].isna().sum().sum()),
                    station_voltage_mean=q.Voltage.mean(),station_feedrate_mean=selected_feed.mean(),station_pressure_mean=q[f'Press._Hopper_{hopper}'].mean(),
                    within_current_range=q.Current.max()-q.Current.min(),within_argon_range=q.Argon.max()-q.Argon.min(),within_nitrogen_range=q.Nitrogen.max()-q.Nitrogen.min())
            bits=failure_bits(record['voltage_mean'],record['feedrate_mean'],record['pressure_mean'],cfg)
            record.update(voltage_fail=bits[0],feedrate_fail=bits[1],hopper_pressure_fail=bits[2])
            reasons=[]
            if not hopper:reasons.append('unknown_active_hopper')
            if not record['left_boundary_observed'] or not record['right_boundary_observed']:reasons.append('unobserved_product_boundary')
            if record['coverage']<cfg['minimum_sampling_coverage']:reasons.append('sampling_coverage_below_minimum')
            if record['dual_feed_samples']:reasons.append('both_hoppers_feeding')
            if record['other_station_running_samples']:reasons.append('both_stations_running')
            if record['conflict_samples']:reasons.append('timestamp_conflict')
            if record['label_missing_values']:reasons.append('missing_rule_values')
            if any(x is None for x in bits):reasons.append('unknown_rule_mean')
            record['quality_flags']=';'.join(reasons);record['label_valid']=int(not reasons)
            record['failure']=int(any(bits)) if not reasons else None
            record['failure_type']='|'.join(name for name,flag in zip(['voltage','feedrate','hopper_pressure'],bits) if flag==1) if not reasons else 'unknown'
            if record['failure']==0:record['failure_type']='none'
            alternate=failure_bits(record.get('station_voltage_mean',np.nan),record.get('station_feedrate_mean',np.nan),record.get('station_pressure_mean',np.nan),cfg)
            record['averaging_scope_disagreement']=bits!=alternate
            rows.append(record)
    return rows
