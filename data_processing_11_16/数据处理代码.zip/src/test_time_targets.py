import unittest
import pandas as pd
import numpy as np
from training_data import epoch_seconds,make_targets,KINDS
from process_data import Clock

class TimeTargetTests(unittest.TestCase):
    def test_datetime_storage_resolution_does_not_change_seconds(self):
        for unit in ['s','ms','us','ns']:
            s=pd.Series(np.array(['2026-11-09T13:30:00','2026-11-09T13:31:00'],dtype='datetime64['+unit+']'))
            self.assertEqual(int(np.diff(epoch_seconds(s))[0]),60)
            self.assertEqual(epoch_seconds(s)[0],pd.Timestamp('2026-11-09 13:30').value//10**9)
    def fixture(self,preventive=False):
        start=pd.Timestamp('2026-11-09 13:30');ts=np.arange(start.value//10**9,start.value//10**9+7201)
        clock=Clock(ts,np.ones(len(ts),bool))
        f=pd.DataFrame(dict(anchor_id=['a'],timestamp=pd.to_datetime(['2026-11-09 13:30:00']).as_unit('us'),cycle_id=['c'],split=['test']))
        p=pd.DataFrame(dict(cycle_id=['c'],supervised_product_eligible=[1],start=[start]))
        c=pd.DataFrame([dict(cycle_id='c',usable_end=start+pd.Timedelta(hours=2),eol_endpoint=start+pd.Timedelta(minutes=5),eol_strict_observed=int(not preventive),eol_sensor_observed=0,end_event='')])
        ev=pd.DataFrame(dict(cycle_id=['c'],kind=['first_voltage'],time=[start+pd.Timedelta(minutes=5)]))
        return f,p,c,clock,ev
    def test_five_minute_event_has_300_seconds_not_zero(self):
        t=make_targets(*self.fixture(),records=[])
        self.assertEqual(t.first_voltage_seconds.iloc[0],300);self.assertEqual(t.first_voltage_within_1h.iloc[0],1)
        self.assertEqual(t.observation_horizon_seconds.iloc[0],7200)
    def test_preventive_end_never_gets_strict_natural_rul(self):
        t=make_targets(*self.fixture(preventive=True),records=[]);self.assertTrue(t.rul_strict_seconds.isna().all())
    def test_missing_future_is_not_negative_failure(self):
        f,p,c,clock,ev=self.fixture();clock=Clock(clock.ts[:90],np.ones(90,bool));c.loc[0,'usable_end']=f.timestamp.iloc[0]+pd.Timedelta(seconds=89)
        t=make_targets(f,p,c,clock,ev,[]);self.assertTrue(pd.isna(t.first_voltage_within_1h.iloc[0]))

if __name__=='__main__':unittest.main()
