"""One product-level attention CSV and a self-contained, novice-friendly review."""
from pathlib import Path
import argparse,base64,json
import numpy as np
import pandas as pd
from process_data import load,clean,dump,FMT

def rule_evidence(r):
    if r.site_override:return 'HMI均值250.2 mbar触发压力条件；现场PLC记录250且判合格，本件按现场记录标0'
    if not r.label_valid:return '不进入本工艺可用样本；均值及原始位置仅供追溯'
    a=[]
    if r.voltage_fail==1:a.append(f'平均电压{r.voltage_mean:.3f} V < 51 V')
    if r.feedrate_fail==1:a.append(f'平均送料{r.feedrate_mean:.3f} g/min 超出9.1—11.1')
    if r.hopper_pressure_fail==1:a.append(f'平均压力{r.pressure_mean:.3f} mbar 超出100—250')
    return '；'.join(a) or '按实际采样点计算，三个产品平均值均未触发失败条件'

def build(analysis,output):
    output.mkdir(parents=True,exist_ok=True)
    p=load(analysis/'产品级标签.csv',['start','end','label_available_at'])
    records=json.loads((analysis/'Booth2换枪记录与窗口核对.json').read_text('utf-8'))
    candidates=json.loads((analysis/'历史8处候选核对.json').read_text('utf-8'))
    triggers=json.loads((analysis/'连续失败与停喷核对.json').read_text('utf-8'))
    s=json.loads((analysis/'汇总.json').read_text('utf-8'));cfg=json.loads((analysis/'使用的参数.json').read_text('utf-8'))
    audit=load(analysis/'停喷观察全量.csv',['start','end'])
    m=load(analysis/'来源文件清单.csv').fillna('');paths={r.source_id:r.container+('::'+r.zip_member if r.zip_member else '') for r in m.itertuples()}
    z=np.load(analysis/'传感器计时与转台状态.npz');ts=z['timestamp_seconds']
    result=[];cn={'voltage':'电压','feedrate':'送料','hopper_pressure':'料斗压力','none':'未触发','unknown':'待核实'}
    for r in p[p.attention.eq(1)].itertuples():
        expected=int((r.end-r.start).total_seconds()+1)
        lo=int(r.start.value//10**9);hi=int(r.end.value//10**9);l,t=np.searchsorted(ts,[lo,hi+1])
        missing=np.setdiff1d(np.arange(lo,hi+1),ts[l:t]);missing_times=';'.join(pd.to_datetime(missing,unit='s').strftime(FMT))
        ids=r.replacement_candidate_ids if isinstance(r.replacement_candidate_ids,str) else ''
        gid=r.record_context_ids if isinstance(r.record_context_ids,str) else ''
        supported=r.rule_supported_record_ids if isinstance(r.rule_supported_record_ids,str) else ''
        ambiguous=r.ambiguous_record_ids if isinstance(r.ambiguous_record_ids,str) else ''
        related=[c for c in candidates if c['candidate_id'] in ids.split(';')]
        unregistered_ids=';'.join(v for v in str(r.attention_event_ids).split(';') if v.startswith('U_'))
        day_ids=[g['record_id'] for g in records if pd.to_datetime(g['date'],format=FMT).date()==r.start.date()]
        control=bool(pd.notna(r.failure) and r.failure==0 and not r.sampling_released) or bool(r.site_override)
        kind='其他配方测试工单（排除）' if '其他配方' in str(r.quality_flags) else '边界不完整等排除片段' if not r.label_valid else '失败产品' if r.failure==1 else '采样缺失复核后未超标' if r.sampling_released else '现场PLC纠正为合格' if r.site_override else '维护前后正常对照'
        result.append(dict(dataset_eligible=int(r.label_valid),exclusion_reason=r.quality_flags if isinstance(r.quality_flags,str) else '',old_sample_ids=r.old_sample_ids,duration_seconds=r.duration_seconds,turnaround_points=r.turnaround_points,turnaround_times=r.turnaround_times,sample_id=r.product_id,sample_kind=kind,analysis_asset='Booth2',start=r.start.strftime(FMT),end=r.end.strftime(FMT),station=r.station,hopper=r.hopper,
            failure=int(r.failure) if pd.notna(r.failure) else None,failure_hmi=int(r.failure_hmi) if pd.notna(r.failure_hmi) else None,failure_type=r.failure_type,failure_type_cn='、'.join(cn.get(x,x) for x in r.failure_type.split('|')),
            voltage_fail=int(r.voltage_fail) if pd.notna(r.voltage_fail) else None,feedrate_fail=int(r.feedrate_fail) if pd.notna(r.feedrate_fail) else None,hopper_pressure_fail=int(r.hopper_pressure_fail) if pd.notna(r.hopper_pressure_fail) else None,hopper_pressure_fail_hmi=int(r.hopper_pressure_fail_hmi) if pd.notna(r.hopper_pressure_fail_hmi) else None,
            voltage_mean_v=r.voltage_mean,feedrate_mean_g_min=r.feedrate_mean,hopper_pressure_mean_mbar=r.pressure_mean,plc_pressure_mean_mbar=r.plc_pressure_mean,
            rule_evidence=rule_evidence(r),label_source=r.label_source,cause_clue=r.origin_label,cause_explanation=r.origin_evidence,cause_basis=r.cause_basis,
            site_override=int(r.site_override),sampling_released=int(r.sampling_released),previous_failure=r.previous_failure,previous_label_valid=int(r.previous_label_valid),label_valid=int(r.label_valid),
            sampling_coverage=r.coverage,samples=int(r.samples),expected_samples=expected,missing_samples=len(missing),missing_timestamps=missing_times,spray_samples=int(r.spray_samples),quality_flags=r.quality_flags if isinstance(r.quality_flags,str) else '',
            derived_shutdown_trigger=int(r.derived_shutdown_trigger),consecutive_failure_count=int(r.consecutive_failure_count),shutdown_trigger_scope='相邻产品诊断；批次未知，非已确认PLC触发',same_batch_confirmed=0,
            event_ids=r.attention_event_ids if isinstance(r.attention_event_ids,str) else '',unregistered_low_stop_ids=unregistered_ids,replacement_candidate_ids=ids,replacement_assessment='；'.join([*[c['candidate_id']+'：'+c['updated_assessment'] for c in related],*([unregistered_ids+'：连续低压后停喷，缺少同日登记，是否换枪待核实'] if unregistered_ids else [])]),
            replacement_windows='；'.join(c['candidate_id']+'：'+c['start']+' 至 '+c['end'] for c in related),replacement_action_confirmed=int(bool(supported)),replacement_confirmation_level='site_rule_window' if supported else 'ambiguous_record_window' if ambiguous else 'unconfirmed',replacement_exact_time='',replacement_exact_time_confirmed=0,
            record_context_ids=gid,rule_supported_record_ids=r.rule_supported_record_ids if isinstance(r.rule_supported_record_ids,str) else '',ambiguous_record_ids=r.ambiguous_record_ids if isinstance(r.ambiguous_record_ids,str) else '',gun_change_on_same_date_ids=';'.join(day_ids),record_matches_exact_product_time=0,normal_comparison=int(control),
            record_cycle_id=r.record_cycle_id,gun_serial_from_record=r.gun_serial_from_record if isinstance(r.gun_serial_from_record,str) else '',gun_cycle_assignment=r.gun_cycle_assignment,
            observed_gun_age_min_hours=r.observed_gun_age_min_hours,possible_gun_age_max_hours=r.possible_gun_age_max_hours,
            source_start=paths[r.source_start],source_start_row=int(r.source_row_start),source_end=paths[r.source_end],source_end_row=int(r.source_row_end),label_available_at=r.label_available_at.strftime(FMT) if pd.notna(r.label_available_at) else '',
            evidence_view='review.html#sample-'+r.product_id,assessment_mode='离线数据标注与记录核对，未训练模型'))
    d=pd.DataFrame(result)
    d=d[['sample_id']+[c for c in d if c!='sample_id']]
    for col in ['failure','failure_hmi','previous_failure']:d[col]=d[col].astype('Int64')
    d.to_csv(output/'label_samples.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    normal=p[p.failure.eq(0)].copy();normal.loc[normal.site_override.eq(1),'pressure_mean']=normal.loc[normal.site_override.eq(1),'plc_pressure_mean']
    normal['day']=normal.start.dt.strftime('%m-%d')
    daily=normal.groupby('day').agg(count=('product_id','size'),voltage=('voltage_mean','median'),feedrate=('feedrate_mean','median'),pressure=('pressure_mean','median')).reset_index()
    model=load(output/'model_data/products.csv')
    d=d.merge(model[['product_id','cycle_id','split','supervised_product_eligible','site_timing_uncertain']],left_on='sample_id',right_on='product_id',validate='one_to_one').drop(columns='product_id')
    d['replacement_confirmation_level']=np.where(d.replacement_action_confirmed.eq(1),'record_or_site_supported_context','unconfirmed_context')
    d['replacement_assessment']=d['replacement_assessment'].str.replace('连续低压后停喷，缺少同日登记，是否换枪待核实','低压后停喷，未关联到一次已确认的更换；见HTML第4部分',regex=False)
    d['shutdown_trigger_scope']='相邻产品诊断；历史批次未记录，不能复现全部PLC计数'
    d.to_csv(output/'label_samples.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    s.update(normal_context_products=int(d.normal_comparison.sum()),csv_kinds=d.sample_kind.value_counts().to_dict())
    for g in records:
        q=audit[audit.window_id.isin(g['window_ids'].split(';'))]
        g['window_rows']=clean(q.to_dict('records'))
        g['context_product_ids']=';'.join(p.loc[p.record_context_ids.fillna('').str.split(';').map(lambda ids:g['record_id'] in ids),'product_id'])
    ref=load(analysis/'参考样本/末期产品核对.csv',['start','end'])
    events=load(analysis/'关注事件索引.csv',['start','end'])
    unregistered=json.loads((analysis/'未登记低压停喷线索.json').read_text('utf-8'))
    payload=dict(summary=s,config=cfg,samples=d.to_dict('records'),candidates=candidates,records=records,record_figures=events[events.event_kind.eq('record_window')].to_dict('records'),unregistered_low_stops=unregistered,shutdown_triggers=triggers,audit=audit.to_dict('records'),
        unknown_examples=d[d.sampling_released.eq(1)].head(1).to_dict('records'),normal_daily=daily.to_dict('records'),normal_stats={k:normal[k].describe(percentiles=[.1,.5,.9]).to_dict() for k in ['voltage_mean','feedrate_mean','pressure_mean']},
        reference_products=ref[ref.start.ge('2026-10-27 13:35')&ref.start.le('2026-10-27 14:20')].to_dict('records'),
        images={f.name:'data:image/png;base64,'+base64.b64encode(f.read_bytes()).decode('ascii') for f in (analysis/'图表').glob('*.png')})
    payload['training']=json.loads((analysis/'训练数据准备.json').read_text('utf-8'))
    payload['cycles']=load(output/'model_data/electrode_cycles.csv').to_dict('records')
    payload['unknown_products']=d[d.label_valid.eq(0)].to_dict('records')
    payload['normal_example_id']=p[p.old_sample_ids.fillna('').str.split(';').map(lambda ids:'P001161' in ids)].product_id.iloc[0]
    payload['plc_override_id']=p[p.site_override.eq(1)].product_id.iloc[0]
    payload['segmentation_info']=json.loads((analysis/'产品分段核对.json').read_text('utf-8'))
    payload['baseline']=load(analysis/'夜间静止基线.csv').to_dict('records')
    payload['mapping_examples']=p[p.old_sample_ids.fillna('').str.contains('P000610|P000732')].to_dict('records')
    payload['failure_examples']=[dict(id=r.event_id,title=r.origin_label) for r in events[events.event_kind.eq('product_failure')].head(5).itertuples()]
    payload['reference_scope_count']=len(ref[ref.start.ge('2026-10-27 13:35')&ref.start.le('2026-10-27 14:20')])
    payload['reference_scope_low_count']=int(ref[ref.start.ge('2026-10-27 13:35')&ref.start.le('2026-10-27 14:20')].reference_voltage_fail.eq(1).sum())
    blob=json.dumps(clean(payload),ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
    template=Path(__file__).with_name('review_final_template.html').read_text('utf-8')
    (output/'review.html').write_text(template.replace('/*__LOGIC__*/',Path(__file__).with_name('review_final_logic.js').read_text('utf-8').replace('/*__DATA__*/',blob)).replace('/*__STYLE__*/',Path(__file__).with_name('review.css').read_text('utf-8')),encoding='utf-8')
    dump(s,analysis/'汇总.json');return s

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--analysis-dir',type=Path,required=True);a.add_argument('--output',type=Path,required=True);v=a.parse_args();print(json.dumps(clean(build(v.analysis_dir,v.output)),ensure_ascii=False,indent=2))
