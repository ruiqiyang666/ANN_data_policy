"""Independent raw-value and full-cycle boundary audit for the 11/12 output."""
from pathlib import Path
import argparse,hashlib,io,json
import numpy as np
import pandas as pd
import data_io as raw
from common import load,dump,FMT

def verify(root,out):
 p=load(out/'产品级标签.csv',['start','end']);m=load(out/'来源文件清单.csv',['time_start','time_end']).fillna({'zip_member':'','identical_bytes_to':''})
 cols=['Date-Time','Voltage','Station_1','Station_2','Current','Power','Feedrate_1','Feedrate_2','Press._Hopper_1','Press._Hopper_2']
 checked=0;points=0;bridge_points=0;night_baseline=[]
 for day,q in p.groupby(p.start.dt.date):
  parts=[]
  for r in m[m.data_stream.eq('main')&m.time_start.dt.date.eq(day)&m.rows.gt(0)&m.identical_bytes_to.eq('')].to_dict('records'):
   b=raw.payload(root,r);assert hashlib.sha256(b).hexdigest()==r['sha256']
   d=pd.read_csv(io.BytesIO(b),sep=';',skipinitialspace=True,usecols=lambda c:c.strip() in cols);d.columns=d.columns.str.strip();d['timestamp']=pd.to_datetime(d['Date-Time'],format=FMT);d['source_id']=r['source_id'];d['source_row']=np.arange(len(d))+2;parts.append(d)
  d=pd.concat(parts,ignore_index=True).sort_values('timestamp').reset_index(drop=True);d=d.drop_duplicates('timestamp',keep='first').reset_index(drop=True);t=d.timestamp.to_numpy()
  for r in q.itertuples():
   lo,hi=np.searchsorted(t,[r.start.to_datetime64(),r.end.to_datetime64()],side='left');z=d.iloc[lo:hi+1]
   assert z.timestamp.iloc[0]==r.start and z.timestamp.iloc[-1]==r.end and len(z)==r.samples,r.product_id
   selected=z[z[f'Feedrate_{int(r.hopper)}'].gt(0)]
   values=[selected.Voltage.mean(),selected[f'Feedrate_{int(r.hopper)}'].mean(),selected[f'Press._Hopper_{int(r.hopper)}'].mean()]
   assert np.allclose(values,[r.voltage_mean,r.feedrate_mean,r.pressure_mean],rtol=0,atol=1e-8),r.product_id
   assert z.source_id.iloc[0]==r.source_start and z.source_row.iloc[0]==r.source_row_start
   assert z.source_id.iloc[-1]==r.source_end and z.source_row.iloc[-1]==r.source_row_end
   low=z[z[f'Station_{int(r.station)}'].abs().le(50)]
   assert len(low)==r.turnaround_points,r.product_id
   if len(low):
    assert (low.Current.gt(100)&low.Power.gt(5)&(low.Feedrate_1.gt(0)|low.Feedrate_2.gt(0))).all()
    assert low[f'Station_{3-int(r.station)}'].abs().le(50).all()
    intervals=low.timestamp.diff().dt.total_seconds().ne(1).cumsum()
    assert low.groupby(intervals).size().max()<=2
    bridge_points+=len(low)
   assert not (z.Feedrate_1.gt(0).any() and z.Feedrate_2.gt(0).any()),'Hopper switch inside cycle needs review: '+r.product_id
   if r.label_valid:
    assert 55<=r.duration_seconds<=85 and not z[f'Station_{3-int(r.station)}'].abs().gt(50).any()
    assert lo>0 and hi+1<len(d)
    assert abs(d[f'Station_{int(r.station)}'].iloc[lo-1])<=50 and abs(d[f'Station_{int(r.station)}'].iloc[hi+1])<=50
    v,f,h=values;bits=(int(round(v,10)<51),int(round(f,10)<9.1 or round(f,10)>11.1),int(round(h,10)<100 or round(h,10)>250))
    if r.site_override:assert 'P003507' in r.old_sample_ids and r.pressure_mean==250.2 and r.plc_pressure_mean==250 and r.failure==0
    else:assert bits==(r.voltage_fail,r.feedrate_fail,r.hopper_pressure_fail) and int(any(bits))==r.failure
   else:assert pd.isna(r.failure) and r.quality_flags
   points+=len(z);checked+=1
  # Baseline requires at least ten observed quiet minutes, not a clock label alone.
  quiet=(d.timestamp.dt.hour.lt(5)&d.Station_1.abs().le(50)&d.Station_2.abs().le(50))
  group=(quiet.ne(quiet.shift(fill_value=False))|d.timestamp.diff().dt.total_seconds().gt(2)).cumsum()
  for _,z in d[quiet].groupby(group[quiet]):
   if len(z)>=600:night_baseline.append(dict(start=z.timestamp.iloc[0],end=z.timestamp.iloc[-1],points=len(z),station1_median=z.Station_1.median(),station1_p99=z.Station_1.quantile(.99),station2_median=z.Station_2.median(),station2_p99=z.Station_2.quantile(.99)))
  if checked%1000<300:print('Independent cycle checks:',checked,flush=True)
 assert p.product_id.is_unique and len(p)==checked
 assert p.loc[p.start.between('2026-10-05 00:37','2026-10-05 00:49'),'label_valid'].eq(1).all(),'Confirmed night processing was incorrectly excluded'
 assert p.loc[p.quality_flags.fillna('').str.contains('9/20'),'failure'].isna().all()
 raw.write_csv(pd.DataFrame(night_baseline),out/'夜间静止基线.csv')
 mapping=load(out/'新旧产品编号对照.csv')
 assert mapping.old_sample_id.nunique()==12638
 for oldids,expected in [(['P000610','P000611'],52.22923076923077),(['P000732','P000733'],48.86)]:
  ids=mapping[mapping.old_sample_id.isin(oldids)].sample_id.unique();assert len(ids)==1
  r=p[p.product_id.eq(ids[0])].iloc[0];assert r.duration_seconds==65 and abs(r.voltage_mean-expected)<1e-8
 result=dict(all_intervals_recalculated=checked,raw_points_in_intervals=points,turnaround_points_checked=bridge_points,all_source_bytes_verified=True,all_means_and_rule_labels_match=True,all_turnaround_gaps_observed_and_power_feed_continuous=True,all_known_intervals_have_visible_outer_boundaries=True,all_12638_old_fragments_mapped=True,site_plc_override_matches_unchanged_physical_interval=True,night_processing_kept=True,night_baseline_continuous_10min_intervals=len(night_baseline),models_trained=False)
 dump(result,out/'验证结果.json');print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--root',type=Path,required=True);a.add_argument('--output',type=Path,required=True);v=a.parse_args();verify(v.root,v.output)
