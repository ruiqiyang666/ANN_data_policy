"""Product mean rules and shared serialization, with site-confirmed PLC override."""

import json
import numpy as np
import pandas as pd
from data_io import TIME_FORMAT as FMT

def load(path,dates=()):
    d=pd.read_csv(path,low_memory=False)
    for col in dates:
        if col in d:d[col]=pd.to_datetime(d[col],format=FMT,errors='coerce')
    return d

def clean(x):
    if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v) for v in x]
    if isinstance(x,pd.Timestamp):return x.strftime(FMT) if pd.notna(x) else None
    if x is pd.NaT or x is pd.NA:return None
    if isinstance(x,(np.integer,np.floating,np.bool_)):x=x.item()
    if isinstance(x,float) and not np.isfinite(x):return None
    return x

def dump(x,path):path.write_text(json.dumps(clean(x),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def bits(v,f,p):
    v,f,p=np.round([v,f,p],10)
    return int(v<51),int(f<9.1 or f>11.1),int(p<100 or p>250)

def revise_products(p,cfg):
    p=p.sort_values(['start','station']).reset_index(drop=True).copy()
    p['previous_failure']=p.failure;p['previous_label_valid']=p.label_valid
    p['sampling_released']=0;p['plc_pressure_mean']=np.nan;p['site_override']=0
    p['label_source']='HMI导出点均值';p['batch_id']=''
    for ix,r in p.iterrows():
        flags=str(r.quality_flags).split(';') if pd.notna(r.quality_flags) else []
        flags=[f for f in flags if f and f!='sampling_coverage_below_minimum']
        p.loc[ix,'quality_flags']=';'.join(flags)
        valid=not flags
        p.loc[ix,'label_valid']=int(valid)
        p.loc[ix,'sampling_released']=int(bool(getattr(r,'legacy_sampling_review',0)) and valid)
        v,f,h=bits(r.voltage_mean,r.feedrate_mean,r.pressure_mean)
        for key,value in zip(['voltage_fail_hmi','feedrate_fail_hmi','hopper_pressure_fail_hmi'],[v,f,h]):p.loc[ix,key]=value if valid else pd.NA
        p.loc[ix,'failure_hmi']=int(v or f or h) if valid else pd.NA
        for key,value in zip(['voltage_fail','feedrate_fail','hopper_pressure_fail'],[v,f,h]):p.loc[ix,key]=value if valid else pd.NA
        p.loc[ix,'failure']=int(v or f or h) if valid else pd.NA
        override=cfg['confirmed_product_overrides'].get(r.product_id)
        if override:
            assert valid and 'P003507' in r.old_sample_ids.split(';')
            p.loc[ix,'hopper_pressure_fail']=override['hopper_pressure_fail'];p.loc[ix,'failure']=override['failure']
            p.loc[ix,'plc_pressure_mean']=override['plc_pressure_mean'];p.loc[ix,'site_override']=1
            p.loc[ix,'label_source']='现场PLC记录纠正（案例回复20261103）'
    for key in ['voltage_fail','feedrate_fail','hopper_pressure_fail','failure','voltage_fail_hmi','feedrate_fail_hmi','hopper_pressure_fail_hmi','failure_hmi']:
        p[key]=p[key].astype('Int64')
    p['failure_type']=['|'.join(k for k,f in zip(['voltage','feedrate','hopper_pressure'],[r.voltage_fail,r.feedrate_fail,r.hopper_pressure_fail]) if f==1) or 'none' if r.label_valid else 'unknown' for r in p.itertuples()]
    p['origin_label']=[('已排除的特殊加工段' if '9/20' in str(r.quality_flags) else '非典型加工待核实') if not r.label_valid else '低压失败：寿命末期或偶发失稳待核实' if r.voltage_fail==1 else '活动料斗送料均值超标' if r.feedrate_fail==1 else '活动料斗压力均值超标' if r.hopper_pressure_fail==1 else '现场PLC判定合格' if r.site_override else '三个观测均值未超标' for r in p.itertuples()]
    p['origin_evidence']=['本区间因'+str(r.quality_flags)+'暂不进入可用样本；实测均值仅供核查，不标为合格或失败。' if not r.label_valid else '低压不自动等于寿命耗尽；现场补充新电极品质不佳时可偶发低压，恢复后继续使用。' if r.voltage_fail==1 else 'HMI计算250.2 mbar，现场PLC记录250且判合格；仅纠正此件，其他阈值不变。' if r.site_override else '按实际有效采样点计算，三个产品平均值均在工艺范围内。' if r.failure==0 else '按实际有效采样点计算整件均值；送料、压力物理根因未逐件确认。' for r in p.itertuples()]
    p['cause_basis']=['unknown' if not r.label_valid else 'low_voltage_cause_unresolved' if r.voltage_fail==1 else 'site_plc_product_record' if r.site_override else 'hmi_mean_rule' for r in p.itertuples()]
    # Without batches this is a diagnostic sequence, never a confirmed PLC trigger.
    p['derived_shutdown_trigger']=pd.Series(0,index=p.index,dtype='Int64');p['consecutive_failure_count']=0
    run=0;previous=None
    for ix,r in p.iterrows():
        if r.label_valid and r.failure==1:
            run=run+1 if previous is not None and (r.start-previous).total_seconds()<=1800 else 1
            p.loc[ix,'consecutive_failure_count']=run;p.loc[ix,'derived_shutdown_trigger']=int(run==2);previous=r.end
        else:run=0;previous=None
    return p

def shutdown_followup(p,state,audit):
    off=state[~state.powered].sort_values('start');rows=[]
    for ix in p.index[p.derived_shutdown_trigger.eq(1)]:
        left=ix-1;right=ix
        while right+1<len(p) and p.iloc[right+1].consecutive_failure_count==right-left+2:right+=1
        q=p.iloc[left:right+1];last=q.iloc[-1];following=p.iloc[right+1] if right+1<len(p) else None
        later=off[off.start.gt(last.end)];stop=later.iloc[0] if len(later) else None
        relation='no_immediate_stop'
        if stop is not None and (stop.start-last.end).total_seconds()<=120 and (following is None or stop.start<following.start):relation='direct'
        elif stop is not None and following is not None and following.failure==0:
            next2=p.iloc[right+2] if right+2<len(p) else None
            if (stop.start-following.end).total_seconds()<=120 and (following.start-last.end).total_seconds()<=1800 and (next2 is None or stop.start<next2.start):relation='one_normal_then_stop'
        observed=stop if relation!='no_immediate_stop' else None
        matched=audit[audit.start.eq(observed.start)] if observed is not None else audit.iloc[:0]
        rows.append(dict(trigger_id=f'T{len(rows)+1:03d}',trigger_product_id=p.iloc[ix].product_id,trigger_at=p.iloc[ix].end,failure_type=p.iloc[ix].failure_type,run_start=q.start.iloc[0],run_end=last.end,failed_products=len(q),product_ids=';'.join(q.product_id),stop_relation=relation,observed_stop_at=observed.start if observed is not None else None,seconds_after_last_failure=(observed.start-last.end).total_seconds() if observed is not None else None,next_product_id=following.product_id if following is not None else '',next_product_voltage=following.voltage_mean if following is not None else None,candidate_ids=';'.join(matched.candidate_id.dropna().astype(str)),same_batch_confirmed=False,plc_shutdown_trigger_confirmed=False))
    return rows
