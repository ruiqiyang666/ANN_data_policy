"""Keep the original register and the dated site corrections as separate evidence."""
import pandas as pd
import numpy as np

REPLY='案例回复 20261113.docx'

def align(records,audit,p,clock):
    for g in records:
        for key in ['date','old_serial','new_serial','working_hours','ignitions']:
            g['source_'+key]=g[key]
        g['evidence_source']='Booth2 Excel登记及现场规则'
        g['site_note']='登记当天连续低压后停喷；具体拆装时刻未记录。'
        g['action_type']='replacement_reason_unresolved'
        g['confirmation']='record_and_signal' if g['match_state']=='unique_site_rule' else 'record_confirmed'
    def add(id,day,old='',new='',note='',source=REPLY):
        r=dict(records[0]);r.update(record_id=id,date=pd.Timestamp(day),source_date=pd.NaT,source_row=None,
          source_sheet='',source_cells='',work_order='',old_serial=old,new_serial=new,working_hours=np.nan,ignitions=np.nan,
          source_old_serial='',source_new_serial='',source_working_hours=np.nan,source_ignitions=np.nan,
          evidence_source=source,site_note=note,record_action_confirmed=True,confirmation='site_confirmed',
          exact_change_time='',exact_time_confirmed=False,time_precision='observed_window',
          match_state='record_only_no_low_stop',low_stop_window_ids='',supported_window_ids='',window_ids='',illustration_window='')
        records.append(r);return r
    add('S001','2026-09-29','AF4MBXL032322-1','AF4MBXL042016-8','现场确认9/29实际更换，Excel漏记；不补造累计小时及点火次数。')
    add('S002','2026-11-09','','','用户转述现场：11/9约13:30更换电极。新电极寿命过程可在后续数据中观察。','用户2026-11-16提供的现场信息')
    explicit={
      'S001':('W053','natural_eol','现场确认9/29低压后已换枪，Excel漏记。'),
      'G003':('W069','natural_eol','现场确认：先偶发低压，随后寿命终结并更换。'),
      'G004':('W078','natural_eol','现场确认：先末期波动，随后寿命终结并更换。'),
      'G005':('W104','natural_eol','换枪发生在10/14晚至10/15早之间；序列号观察另列，不增加第三次更换。'),
      'G006':('W108','short_life_eol','现场确认10/15中午更换；早段W105不是另一次已确认更换。旧电极寿命很短，可能品质不佳。'),
      'G007':('W124','preventive','现场确认10/20约14:20提前更换，不要求此前有连续低压。'),
      'G008':('W140','natural_eol','现场确认实际更换日为10/28，原Excel10/29日期有误；只计一次。'),
      'G010':('W174','preventive','现场确认11/6生产结束后提前更换。W174为生产结束后的首段长停喷，仅限定可操作范围，具体分钟未记录。'),
      'S002':('W181','replacement_after_reported_damage','现场告知11/9约13:30更换；数据在13:30:19—13:37:20停喷。当天未检出产品均值低压，不把维护原因改写成两件低压。')}
    for g in records:
        id=g['record_id']
        if id=='G008':g['date']=pd.Timestamp('2026-10-28')
        if id in explicit:
            wid,kind,note=explicit[id];w=audit[audit.window_id.eq(wid)].iloc[0]
            g.update(match_state='site_confirmed',supported_window_ids=wid,low_stop_window_ids=wid if w.site_rule_stop_eligible else '',
              matched_start=w.start,matched_end=w.end,illustration_window=wid,confirmation='site_confirmed',action_type=kind,
              evidence_source=REPLY if id not in ['G010','S002'] else '用户2026-11-16提供的现场信息＋Booth2登记',site_note=note)
        elif g['match_state']=='unique_site_rule':g['action_type']='low_voltage_then_replacement'
        if id=='G006':g['serial_observations']='10/14晚：AF4MBXL032322-7；10/15早：AF4MBXL032322-1；10/15午后：AF4MBXL042016-8（现场回复）'
        if id=='G005':g['serial_observations']='现场观察10/14晚为AF4MBXL032322-7，与Excel换下枪号AF4MBXL042016-8不同；不改写原表枪号。'
        g['sensor_window_supported_by_site_rule']=g['match_state']=='unique_site_rule'
        g['time_precision']='site_approximate_1330' if id=='S002' else 'after_work_date_only' if id=='G010' else 'observed_window'
        g['action_time_lower']=g.get('matched_start',g['date'])
        g['action_time_upper']=min(g.get('matched_end',g['date']+pd.Timedelta(days=1)),g['date']+pd.Timedelta(days=1))
        if id=='G005':g['action_time_upper']=g['matched_end']
        if id=='G010':g['action_time_upper']=pd.Timestamp('2026-11-07')
        g['exact_change_time']='';g['exact_time_confirmed']=False
        day=g['date'];g['window_ids']=';'.join(audit.loc[audit.start.lt(day+pd.Timedelta(days=1))&audit.end.ge(day),'window_id'])
        if g.get('supported_window_ids') and g['supported_window_ids'] not in g['window_ids'].split(';'):
            g['window_ids']=';'.join(filter(None,[g['window_ids'],g['supported_window_ids']]))
    records.sort(key=lambda g:g['action_time_lower'])
    audit['record_ids']='';audit['site_rule_window_supported']=False;audit['record_window_ambiguous']=False
    for i,g in enumerate(records):
        prev=records[i-1] if i else None
        g['serial_chain_matches']=bool(prev and prev['new_serial'] and g['old_serial'] and prev['new_serial']==g['old_serial'])
        if prev:g.update(previous_record_date=prev['date'],previous_source_row=prev['source_row'],previous_new_serial=prev['new_serial'])
        g.update(working_hours_conflict=False,date_bound_hours_conflict=False,working_hours_checkable=False,
          working_comparison_basis='source_register_only',candidate_working_hour_checks=[],counter_hypothesis='',
          working_hours_comparison='原表记录的换下旧电极累计工作时长；不等于更换操作用时，也不用它反推精确更换分钟。')
        g.pop('missing_record_hypothesis',None)
        for wid in filter(None,g['supported_window_ids'].split(';')):
            ix=audit.index[audit.window_id.eq(wid)][0];audit.loc[ix,'record_ids']=g['record_id']
            audit.loc[ix,'site_rule_window_supported']=True
    return records,audit

def assign_cycles(p,records,clock,audit=None):
    """No serial guessed across unresolved source conflicts; ordinal installations split data."""
    p['record_cycle_id']='';p['gun_serial_from_record']='';p['gun_cycle_assignment']=''
    p['observed_gun_age_min_hours']=np.nan;p['possible_gun_age_max_hours']=np.nan
    for j,g in enumerate(records):
        lower=g['action_time_lower'];upper=g['action_time_upper'];end=records[j+1]['action_time_lower'] if j+1<len(records) else p.end.max()+pd.Timedelta(seconds=1)
        hit=p.start.gt(upper)&p.end.lt(end)
        p.loc[hit,'record_cycle_id']='C'+str(j+1).zfill(3)
        serial=g['new_serial'] if g['new_serial'] else ''
        # G005 has conflicting source observations; serial identity is not an input feature.
        if g['record_id']=='G005':serial=''
        p.loc[hit,'gun_serial_from_record']=serial
        p.loc[hit,'gun_cycle_assignment']='按已确认更换先后划分；具体拆装分钟未知。枪号仅为离线来源信息。'
        times=p.loc[hit,'start'].to_numpy(dtype='datetime64[s]').astype(np.int64)
        if len(times):
            stop0=int(pd.Timestamp(upper).value//10**9);a=np.searchsorted(clock.ts,stop0);b=np.searchsorted(clock.ts,times)
            observed=(clock.prefix[b]-clock.prefix[a])/3600
            missing=(times-stop0-(clock.known_prefix[b]-clock.known_prefix[a]))/3600
            p.loc[hit,'observed_gun_age_min_hours']=observed;p.loc[hit,'possible_gun_age_max_hours']=observed+missing
    pre=p.end.lt(records[0]['action_time_lower']);p.loc[pre,'record_cycle_id']='C000'
    p.loc[pre,'gun_cycle_assignment']='数据开始前已安装，周期左侧不完整。'
    for g in records:
        uncertain=p.start.le(g['action_time_upper'])&p.end.ge(g['action_time_lower'])
        p.loc[uncertain,'gun_cycle_assignment']='更换操作时间范围内，产品周期归属不确定，不作精确寿命训练。'
    return p

def label_causes(p):
    p['site_timing_uncertain']=0
    def setids(ids,label,evidence,basis):
        hit=p.product_id.isin(ids);p.loc[hit,['origin_label','origin_evidence','cause_basis']]=[label,evidence,basis]
    setids(['N000499','N000593','N000601'],'现场确认偶发低压，未更换电极',
      '案例回复20261113：该时段电极未更换，存在返工及偶发产品失败；保留产品低压标签，不作为电极寿命终点。','site_confirmed_intermittent')
    p.loc[p.product_id.eq('N000499'),'site_timing_uncertain']=1
    p.loc[p.product_id.eq('N000499'),'origin_evidence']+=' 现场产品时间与HMI区间有偏差，精确时间监督排除此段。'
    setids(['N004518','N005164'],'寿命末期先出现单件低压',
      '案例回复20261113：该件为末期先出现的波动，随后有连续低压、停喷和更换；该件仍为失败，但不是实际更换时刻。','site_confirmed_terminal_fluctuation')
    setids(['N004520','N004521','N004522','N005182','N005183','N006883','N006884','N006885','N009117','N009118','N009119','N009120'],
      '现场确认寿命末期低压，随后更换', '案例回复20261113已确认相应停喷后更换；产品均值低于51 V。','site_confirmed_eol')
    for id in ['N006883','N006884','N006885']:
        p.loc[p.product_id.eq(id),'origin_evidence']+=' 10/15中午这次换下的电极寿命短，现场认为可能品质不佳。'
    for id in ['N012155','N012162','N012163','N012164','N012165']:
        hit=p.product_id.eq(id)
        p.loc[hit,['origin_label','origin_evidence','cause_basis']]=['11/9安装电极的末期低压线索','11/10出现单件低压后，连续4件低压并于13:34:43停喷；复机电压回升。符合末期过程，尚无该日实际更换记录，不补造换枪。','sensor_inferred_terminal_event']
    return p
