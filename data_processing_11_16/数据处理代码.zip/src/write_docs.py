from pathlib import Path
import json,hashlib,platform,sys
import pandas as pd
from common import load,dump

def write(output):
    a=output/'本地核查材料';s=json.loads((a/'汇总.json').read_text('utf-8'));t=s['training_data'];d=pd.read_csv(output/'label_samples.csv')
    (output/'README.md').write_text(f'''# Booth2 数据交付（2026-11-16）

分析范围：2026-09-12—2026-11-14，仅包含已提供的采样；本轮未训练模型。

先下载并用浏览器打开 **review.html**，图和明细已嵌入，可离线筛选、点“看依据”。Gitee通常只显示HTML源码，需要下载后打开。

- **label_samples.csv**：{len(d)}条关注产品，一件一行，包含失败、排除片段、少点复核及维护前后对照。日期保持原始的“日 月 年 时:分:秒”。可用Excel“数据→从文本/CSV”按逗号、UTF-8导入。
- **model_data/**：后续训练用的全量产品、周期划分、传感器输入和未来目标，详情见 **training_handoff.md**。不要只用关注CSV训练。
- **本地核查材料/**：原始位置、完整停喷审查、现场修正依据、日期命名的28参数片段、独立复算与数据检查结果。
- **src/**：可复现处理和报告生成代码；**gitee/**：只包含代码和说明，适合手动上传ruiqi分支。主目录中的报告和数据是否上传，由项目的数据分享要求决定。

整批{ s['products']:,}个候选加工区间：{s['normal_products']:,}件未失败、{s['failed_products']}件失败（电压{s['reason_counts']['voltage_fail']}、送粉{s['reason_counts']['feedrate_fail']}、罐压{s['reason_counts']['hopper_pressure_fail']}），{s['unknown_products']}段排除。N编号为完整周期编号，不是设备条码。旧P编号可在old_sample_ids及新旧编号对照中追溯。

`failure`为最终产品标签：1失败、0未失败、空白为排除。`failure_hmi`保留HMI均值判定；现场PLC已确认的一件压力边界个例另列修正。`failure_type`为voltage/feedrate/hopper_pressure/none/unknown。`rule_evidence`给出具体均值和阈值，`cause_explanation`给出物理原因证据层级。

`dataset_eligible`表示本工艺产品规则是否可判；`supervised_product_eligible`进一步排除现场已指出时间对不齐的一件N000499。因此报告中的产品失败数与严格时间监督可用失败数会相差1件。`replacement_action_confirmed=1`仅表示该产品属于已确认更换的前后对照，不表示加工该产品时发生了更换。实际动作表为model_data/maintenance_events.csv。

已有{ s['recorded_changes']}次已记录或现场确认的更换：10条Booth2 Excel记录，加9/29漏记与11/9现场补充。10/29原日期改为10/28，只计一次。11/10的低压后停喷是单列的传感器末期线索，不当作第13次已确认更换。

核查结果：全部{s['products']:,}个区间已由原始点独立复算；保留换向的短暂低速点，没有把正反转拆成两件。没有使用98%门槛，没有插值。输入源文件未修改。

## 重新运行

依赖Python、pandas、NumPy、openpyxl、matplotlib；图表中文字体使用Microsoft YaHei。运行前准备JJ原始数据，以及11_10数据处理/本地核查材料（保留旧P编号与来源清单，用于可追溯映射）。11_12版本是结构参考，实际标签由本版重新计算。

```powershell
python -B -W ignore::FutureWarning src/run_pipeline.py --root "C:/Users/杨睿奇/Desktop/大三第一学期/JJ" --previous-analysis "C:/Users/杨睿奇/Desktop/大三第一学期/JJ/11_10数据处理/本地核查材料" --gun-records "C:/Users/杨睿奇/Desktop/大三第一学期/JJ/Gun Change Records 换枪记录 (1).xlsx" --output "C:/Users/杨睿奇/Desktop/大三第一学期/JJ/重新生成_11_16"
```

输出目录必须为空。现场确认规则在src/site_alignment.py与config.json中；它们是带来源的历史纠正，不能拿来给未来数据贴结论。源文件有增删时，先更新来源清单和确认规则，不沿用旧缓存。
''',encoding='utf-8')
    (output/'training_handoff.md').write_text(f'''# 下一阶段训练交接

## 目标与当前边界

1. 在同批次连续两件失败停机前，为提前更换电极提供剩余时间预警。
2. 分别预测电压、送粉速率、罐压导致的产品失败，以及相邻连续两件失败。
3. 之后接入实时传感器，展示未来走线与实际曲线的吻合程度。

本阶段只处理数据，没有选模型、训练、预测曲线或性能分数。历史没有批次边界，所有“相邻两件”标签均为诊断序列，不能直接叫PLC停机真值。提前更换时，未观察到自然寿命终点，必须作删失处理。“最合适提前多久换枪”没有唯一真实标签；不能把提前更换的实际时间当作自然失效时间，或固定减去任意分钟充当金标准。需要后续将故障风险与废品、停机代价结合决定策略。

## 文件与粒度

| 文件 | 粒度与作用 |
|---|---|
| products.csv | 全量{ s['products']:,}个完整周期候选；包括正常、失败、排除。产品起止、最终均值、原因、源文件行号是离线标签和追溯信息。 |
| maintenance_events.csv | {s['recorded_changes']}条已记录/现场确认的更换；Excel原日期、原枪号与现场修正并列；action_time_lower/upper是实际操作可能范围，不是拆装耗时。 |
| electrode_cycles.csv | {t['cycles']}段安装／观察周期，唯一cycle_id；其中包含左/右侧不完整段以及I001传感器线索边界，不代表{t['cycles']}次已确认自然失效。 |
| target_events.csv | 单件失败结束、按类型相邻两件失败的诊断时点；plc_trigger_confirmed始终0。 |
| features_10s.csv.gz | {t['feature_anchors']:,}个实际加工中的10秒时点；当时的28个读数、过去60秒均值、电压标准差、历史点数。仅使用timestamp及之前数据。 |
| targets_10s.csv.gz | 同一anchor_id对应未来标签，与输入分开；空值代表未观察/不可判，不是0。 |
| sensor_minutes.csv.gz | 完整分钟时间轴，28项均值与最后有效读数、点数和缺失/排除标记；timestamp为分钟结束(:59)，available_at同为结束时刻。无数据留空，不把午夜/待机当失败产品。 |
| forecast_windows.csv | 每小时一次候选索引；过去1440分钟、未来60分钟必须同周期/同集合。strict_eligible要求每分钟60点且无排除片段。 |
| split_summary.csv | 各集合真实事件与产品数量，重点看失败事件稀少情况。 |
| data_manifest.json | 精确输入列白名单、样本数、监督范围及模型未训练标记。 |

model_data/中CSV为逗号分隔UTF-8；gzip可直接由pandas.read_csv读取，日期用format='%d %m %Y %H:%M:%S'。汇总label_samples.csv只用于人工审阅，不能替代全量产品表。

## 输入和未来目标必须分开

`features_10s.csv.gz`中只有data_manifest.json的input_columns白名单可作数值输入。anchor_id、timestamp、cycle_id、split是索引/划分信息，不作为可学习的故障暗示。数据清洗、缺失填充、缩放等所有拟合只用训练集，验证/测试集不可重新拟合。60秒特征在日期边界、采样断档、更换范围和排除片段处分段；不足60点时保留实际history_points60s，不伪造完整历史。

不要把products中的最终均值、failure、failure_type、cause_basis、最终时长、未来更换记录、终点、现场事后解释或累计寿命倒推值并入同一时刻输入。当前产品的完整均值只有加工结束后才可得到；若将已完成产品统计作为后续输入，必须以label_available_at作向后关联。

当前输入没有捏造历史Gun_Hours/Gun_ID/Ignitions。record_cycle_id是旧核查用来源分组，后续训练统一使用本次cycle_id；L编号标记安装/观察段，不等于设备枪序列号。同一枪体序列号可能重复使用，不能用序列号代替一次电极安装周期。

## 目标列

所有_seconds目标均为源文件本地时间的日历秒，包含夜间和等待，不等于剩余喷涂工作秒。原始设备时区未擅自转换。electrode_cycles同时保存实测带电小时和未知时长，带电估算不是PLC的Gun_Hours；以后训练工作时长目标时，必须单独定义计时口径，不能直接把日历RUL当累计工作小时。

- `first_voltage/feedrate/pressure/any_seconds`：距后续首件对应失败结束的秒数。只监督在同周期且连续可观察范围内的事件；已到当前时刻的事件不算未来。
- `adjacent_two_*_seconds`：距该类相邻第二件失败结束的秒数。它预警产品连续失败，不保证PLC批次触发。正常件、无效件或产品间隔超过30分钟重置诊断计数。
- `*_within_1h`、`*_within_24h`：预测窗口内是否有上述事件。仅在事件已观察，或完整观察到窗口结束时给1/0；其余留空，不能fillna(0)。`observation_horizon_seconds`为至下一采样断档、排除片段或周期边界的保守可观察时长。
- `rul_strict_seconds`：距有更换登记/现场支持的末期低压序列第二件结束。这里的strict说明终点证据层级，**不是精确拆装时间、也不是已确认PLC批次计数**。起点不完整时可监督剩余时间，但不能解释为完整累计寿命。
- `rul_sensor_seconds`：11/10传感器末期过程的较弱终点，仅用于独立分析或弱监督，不与严格测试真值混合。
- `maintenance_time_lower/upper_seconds`：距离实际更换可能范围。用于区间评估、记录匹配，不代表自然失效RUL或最优换枪策略。

提前更换的周期不生成自然末期RUL。11/6提前更换到11/9更换：现场描述11/9损坏，但当天没有产品均值低压；原因保持未复现，不硬贴两件低压停机。11/9约13:30安装到11/10低压停喷的曲线完整可观察，11/10实际更换尚无记录，所以终点证据单列。

## 固定的时间划分

- 训练：10/20约14:20提前更换之前的完整安装/观察段。
- 验证：该次更换之后，到11/6工作结束后的提前更换之前。
- 测试：11/6提前更换之后，包含11/9更换及其后续末期过程、11/10复机后的未闭合观察段。

同一cycle_id只能属于一个集合；更换时间范围不明确的重叠产品不作严格监督。历史输入可按时间因果原则读取较早数据，但未来目标、拟合统计、标签不得越过集合或周期边界。做模型调参只看验证集，测试集保持一次最终评估用途。不要按行随机拆分密集时序窗口。

{pd.read_csv(output/'model_data/split_summary.csv').to_markdown(index=False) if False else pd.read_csv(output/'model_data/split_summary.csv').to_csv(index=False)}

严格完整的24小时历史→60分钟未来窗口目前有{t['strict_forecast_windows']}个。若为0，不表示分钟数据不可用，而是现有缺口/周期边界无法满足这项完整性要求；后续可设计带缺失掩码的时序输入或调整观察窗，再明确说明方法，不能宣称已有完整24小时预测测试。罐压、送粉终点很少，且验证/测试可能没有正例，无法证明三类目标均有可靠泛化能力。密集{t['feature_anchors']:,}个时点不等于同样多的独立故障。

## 实时接口

用户提供的未来接口位于HA.Booth2.Plasma2，包含Voltage、Current、Power、Station_1/2、Feedrate_1/2、Press_Hopper_1/2、Gun_ID.DATA、Gun_Hours、Ignitions。字段映射见live_input_schema.json。

各标签有各自更新时间与质量，不能把截图的一行更新时间当成整表同步时间。先按统一时点作仅向过去的关联，保留字段时间、质量、陈旧程度，不借用下一个采样点回填过去。质量不好或过旧的数据应缺失；陈旧上限需按实际采集协议配置，本次不假定。Gun_ID.LEN是字符串长度，不是枪号。截图虽说明有更换信息，但未明确展示独立更换时间字段名，本次不编造该字段。Gun_Hours的PLC累计口径不直接等同于程序用电流/功率估算的带电时间。

## 核查与限制

全部{s['products']:,}个产品区间、873373个区间内原始点与3081个换向低速点独立复算通过；模型输入与未来目标还经过锚点、周期划分和抽样因果性核对，结果在本地核查材料/训练数据验证.json。

现场纠正优先于冲突Excel原值，来源与哈希保留。N000499的HMI时间与现场产品时间不同，产品低压标签保留，严格时间监督排除。11/6 18:19:51两条不同空闲读数同时存在：两行留存，冲突秒从有效特征和计时排除。其他配方长周期、边界不完整等84段不套用本工艺标签。
''',encoding='utf-8')
    schema=dict(asset='Booth2',prefix='HA.Booth2.Plasma2.',required_per_tag=['value','source_timestamp','quality'],alignment='backward-only as-of; never nearest/future',staleness_seconds=None,
      mappings=[dict(historical=h,live=l,unit=u) for h,l,u in [('Voltage','Voltage','V'),('Current','Current','A'),('Power','Power','kW'),('Station_1','Station_1','rpm'),('Station_2','Station_2','rpm'),('Feedrate_1','Feedrate_1','g/min'),('Feedrate_2','Feedrate_2','g/min'),('Press._Hopper_1','Press_Hopper_1','mbar'),('Press._Hopper_2','Press_Hopper_2','mbar')]],
      future_only_tags={'Gun_ID.DATA':'physical gun identifier; not a unique electrode installation ID','Gun_Hours':'PLC cumulative counter; definition/reset not assumed','Ignitions':'ignition count; definition/reset not assumed'},structural_only=['Gun_ID.LEN'],gun_change_timestamp_field=None,historical_counter_backfill=False,historical_timezone='device wall clock; unspecified',live_timezone=None)
    dump(schema,output/'model_data/live_input_schema.json')
    (output/'交接上下文.md').write_text('''# 项目上下文与资料导航

目标、训练交接和限制以training_handoff.md为准；当前最新成果为同目录review.html、label_samples.csv和model_data/。只处理数据，所有模型以后再做。

## 源资料怎么用

- JJ目录的按日期命名主CSV及周ZIP：Booth2原始传感器数据，按来源清单去除字节重复，完整保留原始值。此次加入20261102-20261107及20261109-20261114两个目录。
- Voltage Sample：Booth1设备，仅作为电压走势参考；不能与Booth2混合训练。瞬时低压并非一律寿命终结，可能待机或新电极失稳；是否有产品要看转台。
- Gun Change Records 换枪记录 (1).xlsx：仅读“新换枪记录”Booth2；工作小时、点火次数属于换下旧电极，不是拆装耗时。别拿2025年的行去对应2026数据。
- 案例回复.docx、案例回复 20261103.docx：实际点均值、偶发低压、批次规则、压力边界PLC合格个例等。
- 案例回复 20261113.docx：现场已确认的偶发/末期原因、9/29漏记、10/15中午更换、10/20提前更换、10/29改10/28、长周期其他配方，优先于冲突Excel。
- 2026-11-16聊天补充：11/6结束生产后提前换枪，11/9损坏并于约13:30再换；后装电极的寿命曲线完整。历史数据未找到11/9低压产品；11/10有末期传感器过程，不编造该日实际更换记录。
- 实时标签截图：Booth2未来在线格式，带每个标签的时间、质量、Gun_ID/Gun_Hours/Ignitions；不是历史连续计数文件。

## 避免重犯

1. 正转后短暂低速再反转仍是一件，不能只看转速瞬间下穿阈值切段。
2. 一件按完整加工均值判定；51 V为产品均值阈值，不是所有闲置秒点的阈值。
3. 产品失败数、连续失败组、停喷段、更换动作数分别统计。送粉/罐压停机不自动等于换枪。
4. 换枪需停电；HMI时间连续不等于没有停电，记录缺口也不单独证明换枪。
5. 低压后恢复不能单独证明换新；现场明确的偶发低压不作为寿命终点。
6. 缺点用实际点数求均值，无98%官方要求；原始值不插补，凌晨真实加工保留。
7. HTML给郭工看，不写修改历史，不堆术语与重复问题。保留八部分结构和逐件证据。
8. 旧10_31、11_02、11_08等版本有失效归因/设备来源/产品拆段问题；11_12纠正换向分段，本版进一步合并现场答复及新增数据。不要从旧版复制失效数量当真值。
9. 主CSV只放关注样本；训练使用model_data全量数据。训练、验证、测试按周期和时间划分，未来信息不得作为实时输入。
10. 本地gitee目录只含代码与说明，若手动上传仅用ruiqi分支，不改别人分支。未经确认不要把含传感器数据的CSV或嵌数据HTML上传。

## 现在的进度

已经完成原始来源核对、完整周期重分段、三项阈值标注、现场纠正、更换事件对应、正常对照、参考电压、采样审查、按周期的数据划分，以及实时输入/未来标签分表。当前主要限制是独立故障少、历史PLC批次缺失、更换时刻多为区间、11/10实际操作未留存登记、历史在线计数不存在；不为填齐标签而猜测。
''',encoding='utf-8')
    print('Wrote delivery and training handoff documentation')

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);v=p.parse_args();write(v.output)
